<?php 

	class caja{

		public function agregaCaja($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into tbl_caja(suc_id,
                                      caj_desc,
									  caj_estado)
						values ('$datos[0]',
                                '$datos[1]',
								'Activada')";

			return mysqli_query($conexion,$sql);
        }
        public function obtenDatosCaja($idusuario){

			$c=new conectar();
			$conexion=$c->conexion();
            
			$sql="SELECT caj_id,
			suc_id,
			   caj_desc,
			   caj_estado
	         from tbl_caja 
					where caj_id='$idusuario'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);
		  
			$datos=array(
                            'caj_id' => $ver[0],
						    'suc_id' => $ver[1],
							'caj_desc' => $ver[2],
							'caj_estado' => $ver[3]
						);

			return $datos;
		}


		public function actualizaCaja($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_caja set suc_id='$datos[1]',
                                         caj_desc='$datos[2]',
                                         caj_estado='$datos[3]'
								where caj_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaCaja($esp_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_caja set caj_estado='Cerrada'
								where caj_id='$esp_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>