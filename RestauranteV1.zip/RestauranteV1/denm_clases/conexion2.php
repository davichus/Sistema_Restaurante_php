<?php
	
	$mysqli = new mysqli('localhost', 'root', '', 'restaurante');
	
	if($mysqli->connect_error){
		
		die('Error en la conexion' . $mysqli->connect_error);
		
	}
?>