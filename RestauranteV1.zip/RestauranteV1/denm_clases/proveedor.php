<?php 

	class proveedor{

		public function agregaProv($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into tbl_proveedor(prov_ced,
                                            prov_ruc,
                                            prov_razon_social,
                                            prov_direccion,
                                            prov_telefono,
                                            prov_email,
                                            prov_cta1,
                                            prov_cta2,
                                            prov_observacion,
                                            prov_estado)
						values ('$datos[0]',
                                '$datos[1]',
                                '$datos[2]',
                                '$datos[3]',
                                '$datos[4]',
                                '$datos[5]',
                                '$datos[6]',
                                '$datos[7]',
                                '$datos[8]',
								'A')";

			return mysqli_query($conexion,$sql);
        }
        public function obtenDatosProv($idusuario){

			$c=new conectar();
			$conexion=$c->conexion();
            
			$sql="SELECT prov_id,
            prov_ced,
            prov_ruc,
            prov_razon_social,
            prov_direccion,
            prov_telefono,
            prov_email,
            prov_cta1,
            prov_cta2,
            prov_observacion,
            prov_estado
	         from tbl_proveedor 
					where prov_id='$idusuario'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);
		  
			$datos=array(
                            'prov_id' => $ver[0],
                            'prov_ced' => $ver[1],
                            'prov_ruc' => $ver[2],
                            'prov_razon_social' => $ver[3],
						    'prov_direccion' => $ver[4],
                            'prov_telefono' => $ver[5],
                            'prov_email' => $ver[6],
                            'prov_cta1' => $ver[7],
                            'prov_cta2' => $ver[8],
                            'prov_observacion' => $ver[9],
                            'prov_estado' => $ver[10]
						);

			return $datos;
		}


		public function actualizaProv($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_proveedor set prov_ced='$datos[1]',
                                         prov_ruc='$datos[2]',
                                         prov_razon_social='$datos[3]',
                                         prov_direccion='$datos[4]',
                                         prov_telefono='$datos[5]',
                                         prov_email='$datos[6]',
                                         prov_cta1='$datos[7]',
                                         prov_cta2='$datos[8]',
                                         prov_observacion='$datos[9]'
								where prov_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaProv($esp_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_proveedor set 	prov_estado='I'
								where prov_id='$esp_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>