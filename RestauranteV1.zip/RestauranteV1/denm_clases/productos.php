<?php 

	class productos{

		public function agregaIns($datos){
			$c= new conectar();
			$conexion=$c->conexion();
		 
		
			$sql="INSERT into tbl_insumos(ins_desc,
                                        ins_unidad_tipo,
                                        catin_id,
                                        ins_medidad,
                                        ins_cantidad_medidad,
                                        ins_stock,
                                        ins_stock_medida,
                                        ins_precio,
										ins_estado)
						values ('$datos[0]',
                                '$datos[1]',
                                '$datos[2]',
                                '$datos[3]',
                                '$datos[4]',
                                '$datos[5]',
                                '$datos[6]',
                                '$datos[7]',
								'A')";

			return mysqli_query($conexion,$sql);
		
		}
        public function obtenDatosPro($idusuario){

			$c=new conectar();
			$conexion=$c->conexion();
            
			$sql="SELECT pro_id,
            pro_desc,
            catpro_id,
            pro_destino,
            pro_stock,
            pro_precio,
            suc_id
	         from productos 
					where pro_id='$idusuario'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);
		  
			$datos=array(
                            'pro_id' => $ver[0],
                            'pro_desc' => $ver[1],
                            'catpro_id' => $ver[2],
                            'pro_destino' => $ver[3],
						    'pro_stock' => $ver[4],
                            'pro_precio' => $ver[5],
                            'suc_id' => $ver[6]
						);

			return $datos;
		}
       
		public function actualizaPro($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE productos set pro_desc='$datos[1]',
                                         catpro_id='$datos[2]',
                                         pro_destino='$datos[3]',
                                         pro_stock='$datos[4]',
                                         pro_precio='$datos[5]',
                                         suc_id='$datos[6]'
                                       
								where pro_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaPro($Tper_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE productos set pro_estado='I'
								where pro_id='$Tper_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>