<?php 

	class categoria_insumo{

		public function agregacatin($datos){
			$c= new conectar();
			$conexion=$c->conexion();
		 
		
			$sql="INSERT into tbl_categoria_insumo(catin_desc,
										catin_estado)
						values ('$datos[0]',
								'A')";

			return mysqli_query($conexion,$sql);
		
		}
		
       
		

		public function actualizaCatin($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_categoria_insumo set catin_desc='$datos[1]'
								where catin_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaCatin($Tper_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_categoria_insumo set catin_estado='I'
								where catin_id='$Tper_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>