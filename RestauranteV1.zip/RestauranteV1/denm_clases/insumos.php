<?php 

	class insumos{

		public function agregaIns($datos){
			$c= new conectar();
			$conexion=$c->conexion();
		 
		
			$sql="INSERT into tbl_insumos(ins_desc,
                                        ins_unidad_tipo,
                                        catin_id,
                                        ins_medidad,
                                        ins_cantidad_medidad,
                                        ins_stock,
                                        ins_stock_medida,
                                        ins_precio,
										ins_estado)
						values ('$datos[0]',
                                '$datos[1]',
                                '$datos[2]',
                                '$datos[3]',
                                '$datos[4]',
                                '$datos[5]',
                                '$datos[6]',
                                '$datos[7]',
								'A')";

			return mysqli_query($conexion,$sql);
		
		}
        public function obtenDatosIn($idusuario){

			$c=new conectar();
			$conexion=$c->conexion();
            
			$sql="SELECT ins_id,
            ins_desc,
            ins_unidad_tipo,
            catin_id,
            ins_medidad,
            ins_cantidad_medidad,
            ins_stock,
            ins_stock_medida,
            ins_precio,
            ins_estado
	         from tbl_insumos 
					where ins_id='$idusuario'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);
		  
			$datos=array(
                            'ins_id' => $ver[0],
                            'ins_desc' => $ver[1],
                            'ins_unidad_tipo' => $ver[2],
                            'catin_id' => $ver[3],
						    'ins_medidad' => $ver[4],
                            'ins_cantidad_medidad' => $ver[5],
                            'ins_stock' => $ver[6],
                            'ins_stock_medida' => $ver[7],
                            'ins_precio' => $ver[8],
                            'ins_estado' => $ver[9]
						);

			return $datos;
		}
       
		public function actualizaIn($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_insumos set ins_desc='$datos[1]',
                                         ins_unidad_tipo='$datos[2]',
                                         catin_id='$datos[3]',
                                         ins_medidad='$datos[4]',
                                         ins_cantidad_medidad='$datos[5]',
                                         ins_stock='$datos[6]',
                                         ins_stock_medida='$datos[7]',
                                         ins_precio='$datos[8]'
								where ins_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaIn($Tper_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_insumos set ins_estado='I'
								where ins_id='$Tper_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>