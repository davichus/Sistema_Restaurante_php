<?php 

	class mesa{

		public function agregaMesa($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into tbl_mesa(suc_id,
                                      mes_desc,
                                      mes_sillas,
									  mes_estado)
						values ('$datos[0]',
                                '$datos[1]',
                                '$datos[2]',
								'A')";

			return mysqli_query($conexion,$sql);
        }
        public function obtenDatosMesa($idusuario){

			$c=new conectar();
			$conexion=$c->conexion();
            
			$sql="SELECT mes_id,
			    suc_id,
			    mes_desc,
                mes_sillas,
			    mes_estado
	         from tbl_mesa 
					where mes_id='$idusuario'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);
		  
			$datos=array(
                            'mes_id' => $ver[0],
						    'suc_id' => $ver[1],
                            'mes_desc' => $ver[2],
                            'mes_sillas' => $ver[3],
							'mes_estado' => $ver[4]
						);

			return $datos;
		}


		public function actualizaMesa($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_mesa set suc_id='$datos[1]',
                                         mes_desc='$datos[2]',
                                         mes_sillas='$datos[3]'
								where mes_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaMesa($esp_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_mesa set mes_estado='I'
								where mes_id='$esp_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>