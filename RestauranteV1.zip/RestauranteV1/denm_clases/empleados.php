<?php 

	class empleados{

		public function agregaEmp($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into tbl_empleado(per_id,
                                      suc_id,
									  car_id,
                                      emp_estado)
						values ('$datos[0]',
                                '$datos[1]',
                                '$datos[2]',
								'A')";

			return mysqli_query($conexion,$sql);
        }
        public function obtenDatoseEmp($idusuario){

			$c=new conectar();
			$conexion=$c->conexion();
            
			$sql="SELECT emp_id,
            per_id,
			suc_id,
            car_id
	         from tbl_empleado 
					where emp_id='$idusuario'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);
		  
			$datos=array(
                            'emp_id' => $ver[0],
                            'per_id' => $ver[1],
                            'suc_id' => $ver[2],
                            'car_id' => $ver[3]
						);

			return $datos;
		}


		public function actualizaEmp($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_empleado set  per_id='$datos[1]',
			                               
                                           car_id='$datos[2]'
                                          
								where emp_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaEmp($esp_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_empleado set emp_estado='I'
								where emp_id='$esp_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>