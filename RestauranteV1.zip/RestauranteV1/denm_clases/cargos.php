<?php 

	class cargos{

		public function agregaCargo($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into tbl_cargo(car_desc,
                                      suc_id,
									  car_estado)
						values ('$datos[0]',
                                '$datos[1]',
								'A')";

			return mysqli_query($conexion,$sql);
        }
        public function obtenDatosCargo($idusuario){

			$c=new conectar();
			$conexion=$c->conexion();
            
			$sql="SELECT car_id,
            car_desc,
			suc_id
	         from tbl_cargo 
					where car_id='$idusuario'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);
		  
			$datos=array(
                            'car_id' => $ver[0],
                            'car_desc' => $ver[1],
						    'suc_id' => $ver[2]
						);

			return $datos;
		}


		public function actualizaCargo($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_cargo set  car_desc='$datos[1]',
                                        suc_id='$datos[2]'
								where car_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaCargo($esp_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_cargo set car_estado='I'
								where car_id='$esp_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>