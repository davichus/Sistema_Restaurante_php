<?php 

	class venta{

		public function agregaIns($datos){
			$c= new conectar();
			$conexion=$c->conexion();
		 
		
			$sql="INSERT into tbl_insumos(ins_desc,
                                        ins_unidad_tipo,
                                        catin_id,
                                        ins_medidad,
                                        ins_cantidad_medidad,
                                        ins_stock,
                                        ins_stock_medida,
                                        ins_precio,
										ins_estado)
						values ('$datos[0]',
                                '$datos[1]',
                                '$datos[2]',
                                '$datos[3]',
                                '$datos[4]',
                                '$datos[5]',
                                '$datos[6]',
                                '$datos[7]',
								'A')";

			return mysqli_query($conexion,$sql);
		
		}
        public function obtenDatosVen($idusuario){

			$c=new conectar();
			$conexion=$c->conexion();
            
			$sql="SELECT ven_id,
            caj_id,
            ven_efectivo,
            ven_visa,
            ven_mastercard,
            ven_precio,
            pro_estado,
            round((ven_precio*0.12),2)as iva,
            round((ven_precio*0.12)+ven_precio,2)as total
	         from venta 
					where ven_id='$idusuario'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);
		  
			$datos=array(
                            'ven_id' => $ver[0],
                            'caj_id' => $ver[1],
                            'ven_efectivo' => $ver[2],
                            'ven_visa' => $ver[3],
						    'ven_mastercard' => $ver[4],
                            'ven_precio' => $ver[5],
                            'pro_estado' => $ver[6],
                            'iva' => $ver[7],
                            'total' => $ver[8]
                            
						);

			return $datos;
		}
       
		public function actualizaVen($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE venta set caj_id='$datos[1]',
                                   ven_efectivo='$datos[2]',
                                   ven_visa='$datos[3]',
                                   ven_mastercard='$datos[4]',
                                   ven_precio='$datos[5]',
                                   pro_estado='$datos[6]'
								where ven_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaIn($Tper_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_insumos set ins_estado='I'
								where ins_id='$Tper_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>