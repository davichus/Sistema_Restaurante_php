<?php 

	class categoria_producto{

		public function agregacatpro($datos){
			$c= new conectar();
			$conexion=$c->conexion();
		 
		
			$sql="INSERT into tbl_categoria_producto(catprod_desc,
										catprod_estado)
						values ('$datos[0]',
								'A')";

			return mysqli_query($conexion,$sql);
		
		}
		
		public function actualiza($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_categoria_producto set catprod_desc='$datos[1]'
								where catprod_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaCatin($Tper_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_categoria_producto set catprod_estado='I'
								where catprod_id='$Tper_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>