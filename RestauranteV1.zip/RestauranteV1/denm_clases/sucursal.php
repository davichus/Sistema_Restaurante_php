<?php 

	class sucursal{

		public function agregaSuc($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into tbl_sucursal(suc_nombre,
                                          suc_ruc,
                                          suc_dir,
                                          suc_telf,
                                          suc_correo,
                                          suc_desc,
                                          suc_estado)
						values ('$datos[0]',
                               '$datos[1]',
                               '$datos[2]',
                               '$datos[3]',
                               '$datos[4]',
                               '$datos[5]',
								'A')";

			return mysqli_query($conexion,$sql);
		}

		public function actualizaSuc($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_sucursal set suc_nombre='$datos[1]',
                                         suc_ruc='$datos[2]',
                                         suc_dir='$datos[3]',
                                         suc_telf='$datos[4]',
                                         suc_correo='$datos[5]',
                                         suc_desc='$datos[6]'
								where suc_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaSuc($per_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_sucursal set suc_estado='I'
								where suc_id='$per_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>