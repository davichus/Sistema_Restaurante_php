<?php 

class compras{
	public function obtenDatosInsumo($idproducto){
		$c=new conectar();
		$conexion=$c->conexion();

		$sql="SELECT ins_unidad_tipo,ins_stock,ins_precio
        
        from tbl_insumos where ins_id='$idproducto'";
		$result=mysqli_query($conexion,$sql);

		$ver=mysqli_fetch_row($result);
		$data=array(
		
			'ins_unidad_tipo' => $ver[0],
			'ins_stock' => $ver[1],
			'ins_precio' => $ver[2]
		);		
		return $data;
	}

	public function crearVenta(){
		$c= new conectar();
		$conexion=$c->conexion();

		$fecha=date('Y-m-d');
		$idventa=self::creaFolio();
		$datos=$_SESSION['tablaComprasTemp'];
		$idusuario=$_SESSION['iduser'];
		$r=0;

		for ($i=0; $i < count($datos) ; $i++) { 
			$d=explode("||", $datos[$i]);

			$sql="INSERT into tbl_compras (com_id,
				                        usu_id,
										prov_id,
										ins_id,
										com_precio,
										com_fecha)
							values ('$idventa',
							        '$idusuario',
									'$d[6]',
									'$d[0]',
									'$d[4]',
									'$fecha')";
			$r=$r + $result=mysqli_query($conexion,$sql);
			//self::descuentaCantidad($d[0],1);
		}

		return $r;
	}
		 
	   public function descuentaCantidad($idproducto,$cantidad){
		 $c=new conectar();
		 $conexion=$c->conexion();
		 $sql="SELECT cantidad
			   from articulos
			   where id_producto='$idproducto'";
		  $result=mysqli_query($conexion,$sql);
		  
		 $cantidad1=mysqli_fetch_row($result)[0];
		 
		 $cantidadNueva=abs($cantidad-$cantidad1);

		 $sql="UPDATE articulos set cantidad='$cantidadNueva'
			   where id_producto='$idproducto'";
		 mysqli_query($conexion,$sql);

	   }
        	
	public function creaFolio(){
		$c= new conectar();
		$conexion=$c->conexion();

		$sql="SELECT com_id from tbl_compras group by com_id desc";

		$resul=mysqli_query($conexion,$sql);
		$id=mysqli_fetch_row($resul)[0];

		if($id=="" or $id==null or $id==0){
			return 1;
		}else{
			return $id + 1;
		}
	}
	public function nombreCliente($idCliente){
		$c= new conectar();
		$conexion=$c->conexion();

		 $sql="SELECT apellido,nombre 
			from clientes 
			where id_cliente='$idCliente'";
		$result=mysqli_query($conexion,$sql);

		$ver=mysqli_fetch_row($result);

		return $ver[0]." ".$ver[1];
	}

	public function obtenerTotal($idventa){
		$c= new conectar();
		$conexion=$c->conexion();

		$sql="SELECT precio 
				from ventas 
				where id_venta='$idventa'";
		$result=mysqli_query($conexion,$sql);

		$total=0;

		while($ver=mysqli_fetch_row($result)){
			$total=$total + $ver[0];
		}

		return $total;
	}
}

?>