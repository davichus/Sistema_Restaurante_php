<?php
     include("conexion.php");
    
        
    
     mysqli_select_db($conexion,$db)or die("Error al conectar la Base de Datos");
    
    
     $codigo=$_POST['txt_buscar'];
     
     $resgistros=mysqli_query($conexion,"SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
     from tbl_persona where per_ced='$codigo'");

     ?>


<?php 
	
	require_once "denm_clases/conexion.php";
	$obj= new conectar();
	$conexion=$obj->conexion();

	$sql="SELECT * FROM tbl_usuario u inner join tbl_tipoperfil t on u.Tper_id=t.Tper_id where t.Tper_desperfil='Administrador'";
	$result=mysqli_query($conexion,$sql);
	$validar=0;
	if(mysqli_num_rows($result) > 0){
		$validar=1;
	}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Registrar Administrador</title>
	<link rel="stylesheet" type="text/css" href="librerias/bootstrap/css/bootstrap.css">
	<script src="librerias/jquery-3.2.1.min.js"></script>
	<script src="js/funciones.js"></script>

    <link rel="stylesheet" type="text/css" href="librerias/alertifyjs/css/alertify.css">
    <link rel="stylesheet" type="text/css" href="librerias/alertifyjs/css/themes/default.css">
    <link rel="stylesheet" type="text/css" href="librerias/select2/css/select2.css">



<script src="librerias/jquery-3.2.1.min.js"></script>
<script src="librerias/alertifyjs/alertify.js"></script>
<script src="librerias/bootstrap/js/bootstrap.js"></script>
<script src="librerias/select2/js/select2.js"></script>



</head>
<body>
	<br><br><br>
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
            <table>
                <tr>
                    <td>
      <h1>Datos Personales</h1>
      </td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </td>
      <td>
      <h1>Registrar Usuario</h1>
      </td>
      </tr>
      <tr>
			
                <td>
					<form id="frmPersona">
					    <label>Cedula</label>
						<input type="text" class="form-control input-sm" id="txt_cedula" name="txt_cedula" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Apellido Paterno</label>
						<input type="text" class="form-control input-sm" id="txt_apepat" name="txt_apepat" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Apellido Materno</label>
						<input type="text" class="form-control input-sm" id="txt_apemat" name="txt_apemat" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Nombres</label>
						<input type="text" class="form-control input-sm" id="txt_nom" name="txt_nom" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Genero</label>
							<br>
							<select name="sl_genero" class="form-control input-sm" id="sl_genero" required>
                          <option value="" disabled selected hidden>--Seleccione--</option>
                          <option value="M">Masculino</option>
                          <option value="F">Femenino</option>
                       
                          </select>
                        
                        
                        <label>Fecha Nacimiento</label>
						<input type="date" class="form-control input-sm" id="txt_fecha" name="txt_fecha">
						<label>Telefono</label>
						<input type="text" class="form-control input-sm" id="txt_telf" name="txt_telf" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Direccion</label>
						<input type="text" class="form-control input-sm" id="txt_dir" name="txt_dir">
						<p></p>
						<span class="btn btn-primary" id="btnAgregarPersona">Guardar</span>
                    </form>
                    </td>
                    </td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </td>
      <td>
          
      <form id="frmRegistro" action="resgitrousu.php" method="POST">
          
                    <?php
     
        while($registro=mysqli_fetch_array($resgistros)){
        ?>
                    <h3>Datos Personales</h3>
                    <select class="form-control input-sm" id="sl_persona" name="sl_persona" readonly="">
                
                    
                <option value="<?php echo $registro[0]?>"> <?php echo $registro[2]; ?> <?php echo $registro[3]; ?> <?php echo $registro[4]; ?></option>
                  
                   
                </select>
                    <label>Cedula</label>
                    <input type="text"  readonly="" class="form-control input-sm" id="txt_cedula" name="txt_cedula" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();" value="<?php echo $registro[1]; ?>">
                    <label>Apellidos y Nombres</label>
						<input type="text"  readonly="" class="form-control input-sm" id="txt_apepat" name="txt_apepat" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();" value="<?php echo $registro[2]; ?> <?php echo $registro[3]; ?> <?php echo $registro[4]; ?>">
                   
                        <?php 
          }
        
         ?>   
                   
                        <br>
                        <label>Correo</label>
                            <input type="email" class="form-control input-sm" name="txt_correo" id="txt_correo">
                            <label>Usuario</label>
                            <input type="text" class="form-control input-sm" name="txt_usuario" id="txt_usuario">
                
                            <label>Password</label>
                            <input type="password" class="form-control input-sm" name="txt_pass" id="txt_pass">
                            
                            <?php  if(!$validar){ ?>
                            <label>Rol</label>
                <select class="form-control input-sm" id="sl_rol" name="sl_rol">
                    <option value="A">Selecciona</option>
                    <?php
                    $sql="SELECT Tper_id,
                    Tper_desperfil
                    from tbl_tipoperfil";
                    $result=mysqli_query($conexion,$sql);
    
                    while ($producto=mysqli_fetch_row($result)):
                        ?>
                        <option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
                    <?php endwhile; ?>
                </select>
                
                    <?php }else{ ?>
                        <label>Rol</label>
                        <select class="form-control input-sm" id="sl_rol" name="sl_rol">
                    <option value="A">Selecciona</option>
                    <?php
                    $sql="SELECT Tper_id,
                    Tper_desperfil
                    from tbl_tipoperfil where Tper_desperfil='Cliente'";
                    $result=mysqli_query($conexion,$sql);
    
                    while ($producto=mysqli_fetch_row($result)):
                        ?>
                        <option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
                    <?php endwhile; ?>
                </select>

                        <?php }; ?>
            </center>      
                            <p></p>
                            <center><span class="btn btn-primary" id="registro">Registrarse</span></center>
    
                        </form>
      </td>
                    </tr>
                    </table> 

</body>

<script type="text/javascript">
		$(document).ready(function(){

			$('#btnAgregarPersona').click(function(){

				vacios=validarFormVacio('frmPersona');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmPersona').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"denm_procesos/persona/agregaper.php",
					success:function(r){
						if(r==2){
							
								alertify.alert("Esta Persona ya ha sido registrada, prueba con otro!!");
							}
						
						else if(r==1){
					//esta linea nos permite limpiar el formulario al insetar un registro
					$('#frmPersona')[0].reset();

					alertify.success("Persona agregada con exito!!");
                    location.reload();
				}else{
					alertify.error("No se pudo agregar Persona");
				}
			}
		});
			});
		});
    </script>

<script type="text/javascript">
		$(document).ready(function(){

			

			$('#registro').click(function(){

				vacios=validarFormVacio('frmRegistro');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmRegistro').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"denm_procesos/reglogin/registrarUsuario.php",
					success:function(r){
						//alert(r);
                        var pagina="index.php"
                        if(r==2){
							
								alertify.alert("Este Usuario y Correo Electronico ya existe, prueba con otro!!");
							}
						
						else if(r==1){
							$('#frmRegistro')[0].reset();
							location.href=pagina
							alertify.success("Agregado con exito");
						}else{
							alertify.error("Fallo al agregar :(");
						}
					}
				});
			});
		});
	</script>



    






<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                        alertify.alert("Por favor Ingresa solo letras!!");
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                        alertify.alert("Por favor Ingresa solo numeros!!");
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
<script src="../js/jquery-1.11.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/chart.min.js"></script>
	<script src="../js/chart-data.js"></script>
	<script src="../js/easypiechart.js"></script>
	<script src="../js/easypiechart-data.js"></script>
	<script src="../js/bootstrap-datepicker.js"></script>
	<script src="../js/custom.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>


</html>