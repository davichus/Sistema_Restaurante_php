-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-07-2020 a las 00:00:39
-- Versión del servidor: 10.4.8-MariaDB
-- Versión de PHP: 7.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `restaurante`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `id_com` bigint(20) UNSIGNED NOT NULL,
  `usu_id` int(11) NOT NULL,
  `prov_id` int(11) NOT NULL,
  `codigo` varchar(200) NOT NULL,
  `fecha` datetime NOT NULL,
  `total` decimal(7,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras_vendidos`
--

CREATE TABLE `compras_vendidos` (
  `id_ven` bigint(20) UNSIGNED NOT NULL,
  `ins_id` int(11) NOT NULL,
  `cantidad` bigint(20) UNSIGNED NOT NULL,
  `id_com` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `pro_id` int(11) NOT NULL,
  `pro_desc` varchar(200) DEFAULT NULL,
  `catpro_id` int(11) DEFAULT NULL,
  `pro_destino` varchar(100) DEFAULT NULL,
  `pro_stock` int(11) DEFAULT NULL,
  `pro_precio` decimal(7,2) DEFAULT NULL,
  `suc_id` int(11) DEFAULT NULL,
  `pro_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos_hechos`
--

CREATE TABLE `productos_hechos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ins_id` int(11) NOT NULL,
  `cantidad` bigint(20) UNSIGNED NOT NULL,
  `pro_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_caja`
--

CREATE TABLE `tbl_caja` (
  `caj_id` int(11) NOT NULL,
  `suc_id` int(11) DEFAULT NULL,
  `caj_desc` varchar(50) DEFAULT NULL,
  `caj_estado` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cargo`
--

CREATE TABLE `tbl_cargo` (
  `car_id` int(11) NOT NULL,
  `car_desc` varchar(200) DEFAULT NULL,
  `suc_id` int(11) DEFAULT NULL,
  `car_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_categoria_insumo`
--

CREATE TABLE `tbl_categoria_insumo` (
  `catin_id` int(11) NOT NULL,
  `catin_desc` varchar(100) DEFAULT NULL,
  `catin_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_categoria_producto`
--

CREATE TABLE `tbl_categoria_producto` (
  `catprod_id` int(11) NOT NULL,
  `catprod_desc` varchar(100) DEFAULT NULL,
  `catprod_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_empleado`
--

CREATE TABLE `tbl_empleado` (
  `emp_id` int(11) NOT NULL,
  `per_id` int(11) DEFAULT NULL,
  `suc_id` int(11) DEFAULT NULL,
  `car_id` int(11) DEFAULT NULL,
  `emp_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_insumos`
--

CREATE TABLE `tbl_insumos` (
  `ins_id` int(11) NOT NULL,
  `ins_desc` varchar(200) DEFAULT NULL,
  `ins_unidad_tipo` varchar(100) DEFAULT NULL,
  `catin_id` int(11) DEFAULT NULL,
  `ins_medidad` varchar(100) DEFAULT NULL,
  `ins_cantidad_medidad` float DEFAULT NULL,
  `ins_stock` int(11) DEFAULT NULL,
  `ins_stock_medida` float NOT NULL,
  `ins_precio` float DEFAULT NULL,
  `ins_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_mesa`
--

CREATE TABLE `tbl_mesa` (
  `mes_id` int(11) NOT NULL,
  `suc_id` int(11) DEFAULT NULL,
  `mes_desc` varchar(50) DEFAULT NULL,
  `mes_sillas` int(11) NOT NULL,
  `mes_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_persona`
--

CREATE TABLE `tbl_persona` (
  `per_id` int(11) NOT NULL,
  `per_ced` varchar(10) DEFAULT NULL,
  `per_apepat` varchar(100) DEFAULT NULL,
  `per_apemat` varchar(100) DEFAULT NULL,
  `per_nom` varchar(100) DEFAULT NULL,
  `per_genero` varchar(30) DEFAULT NULL,
  `per_fechanac` varchar(30) DEFAULT NULL,
  `per_telef` varchar(10) DEFAULT NULL,
  `per_direccion` varchar(100) DEFAULT NULL,
  `per_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_productos`
--

CREATE TABLE `tbl_productos` (
  `pro_id` int(11) NOT NULL,
  `pro_desc` varchar(200) DEFAULT NULL,
  `catprod_id` int(11) DEFAULT NULL,
  `pro_destino` varchar(100) DEFAULT NULL,
  `catin_id` int(11) NOT NULL,
  `ins_id` int(11) DEFAULT NULL,
  `pro_stock` int(11) DEFAULT NULL,
  `pro_precio` float DEFAULT NULL,
  `suc_id` int(11) DEFAULT NULL,
  `pro_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_proveedor`
--

CREATE TABLE `tbl_proveedor` (
  `prov_id` int(11) NOT NULL,
  `prov_ced` varchar(10) DEFAULT NULL,
  `prov_ruc` varchar(13) DEFAULT NULL,
  `prov_razon_social` varchar(500) DEFAULT NULL,
  `prov_direccion` varchar(200) DEFAULT NULL,
  `prov_telefono` varchar(13) DEFAULT NULL,
  `prov_email` varchar(200) DEFAULT NULL,
  `prov_cta1` varchar(50) DEFAULT NULL,
  `prov_cta2` varchar(50) DEFAULT NULL,
  `prov_observacion` varchar(100) DEFAULT NULL,
  `prov_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_sucursal`
--

CREATE TABLE `tbl_sucursal` (
  `suc_id` int(11) NOT NULL,
  `suc_nombre` varchar(200) DEFAULT NULL,
  `suc_ruc` varchar(200) DEFAULT NULL,
  `suc_dir` varchar(200) DEFAULT NULL,
  `suc_telf` varchar(200) DEFAULT NULL,
  `suc_correo` varchar(200) DEFAULT NULL,
  `suc_desc` varchar(200) DEFAULT NULL,
  `suc_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_sueldo`
--

CREATE TABLE `tbl_sueldo` (
  `suel_id` int(11) NOT NULL,
  `suel_desc` float DEFAULT NULL,
  `suel_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_tipoperfil`
--

CREATE TABLE `tbl_tipoperfil` (
  `Tper_id` int(11) NOT NULL,
  `Tper_desperfil` varchar(50) DEFAULT NULL,
  `Tper_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_usuario`
--

CREATE TABLE `tbl_usuario` (
  `usu_id` int(11) NOT NULL,
  `per_id` int(11) DEFAULT NULL,
  `usu_correo` varchar(200) DEFAULT NULL,
  `usu_nomlogin` varchar(50) DEFAULT NULL,
  `usu_pass` varchar(50) DEFAULT NULL,
  `Tper_id` int(11) NOT NULL,
  `usu_fecha` date DEFAULT NULL,
  `usu_estado` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta`
--

CREATE TABLE `venta` (
  `ven_id` int(11) NOT NULL,
  `ven_codigo` varchar(200) NOT NULL,
  `usu_id` int(11) DEFAULT NULL,
  `per_id` int(11) DEFAULT NULL,
  `suc_id` int(11) NOT NULL,
  `caj_id` int(11) DEFAULT NULL,
  `mes_id` int(11) DEFAULT NULL,
  `ven_efectivo` decimal(7,2) DEFAULT NULL,
  `ven_visa` decimal(7,2) DEFAULT NULL,
  `ven_mastercard` decimal(7,2) DEFAULT NULL,
  `ven_precio` decimal(7,2) DEFAULT NULL,
  `ven_fecha` date NOT NULL,
  `pro_estado` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas_hechas`
--

CREATE TABLE `ventas_hechas` (
  `id` bigint(20) NOT NULL,
  `pro_id` int(11) NOT NULL,
  `cantidad` bigint(20) NOT NULL,
  `ven_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`id_com`),
  ADD KEY `usu_id` (`usu_id`),
  ADD KEY `prov_id` (`prov_id`);

--
-- Indices de la tabla `compras_vendidos`
--
ALTER TABLE `compras_vendidos`
  ADD PRIMARY KEY (`id_ven`),
  ADD KEY `ins_id` (`ins_id`),
  ADD KEY `id_com` (`id_com`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`pro_id`),
  ADD KEY `suc_id` (`suc_id`),
  ADD KEY `catpro_id` (`catpro_id`);

--
-- Indices de la tabla `productos_hechos`
--
ALTER TABLE `productos_hechos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ins_id` (`ins_id`),
  ADD KEY `pro_id` (`pro_id`);

--
-- Indices de la tabla `tbl_caja`
--
ALTER TABLE `tbl_caja`
  ADD PRIMARY KEY (`caj_id`),
  ADD KEY `suc_id` (`suc_id`);

--
-- Indices de la tabla `tbl_cargo`
--
ALTER TABLE `tbl_cargo`
  ADD PRIMARY KEY (`car_id`),
  ADD KEY `suc_id` (`suc_id`);

--
-- Indices de la tabla `tbl_categoria_insumo`
--
ALTER TABLE `tbl_categoria_insumo`
  ADD PRIMARY KEY (`catin_id`);

--
-- Indices de la tabla `tbl_categoria_producto`
--
ALTER TABLE `tbl_categoria_producto`
  ADD PRIMARY KEY (`catprod_id`);

--
-- Indices de la tabla `tbl_empleado`
--
ALTER TABLE `tbl_empleado`
  ADD PRIMARY KEY (`emp_id`),
  ADD KEY `suc_id` (`suc_id`),
  ADD KEY `per_id` (`per_id`),
  ADD KEY `car_id` (`car_id`);

--
-- Indices de la tabla `tbl_insumos`
--
ALTER TABLE `tbl_insumos`
  ADD PRIMARY KEY (`ins_id`),
  ADD KEY `catin_id` (`catin_id`);

--
-- Indices de la tabla `tbl_mesa`
--
ALTER TABLE `tbl_mesa`
  ADD PRIMARY KEY (`mes_id`),
  ADD KEY `suc_id` (`suc_id`);

--
-- Indices de la tabla `tbl_persona`
--
ALTER TABLE `tbl_persona`
  ADD PRIMARY KEY (`per_id`);

--
-- Indices de la tabla `tbl_productos`
--
ALTER TABLE `tbl_productos`
  ADD PRIMARY KEY (`pro_id`),
  ADD KEY `catprod_id` (`catprod_id`),
  ADD KEY `ins_id` (`ins_id`),
  ADD KEY `suc_id` (`suc_id`),
  ADD KEY `catin_id` (`catin_id`);

--
-- Indices de la tabla `tbl_proveedor`
--
ALTER TABLE `tbl_proveedor`
  ADD PRIMARY KEY (`prov_id`);

--
-- Indices de la tabla `tbl_sucursal`
--
ALTER TABLE `tbl_sucursal`
  ADD PRIMARY KEY (`suc_id`);

--
-- Indices de la tabla `tbl_sueldo`
--
ALTER TABLE `tbl_sueldo`
  ADD PRIMARY KEY (`suel_id`);

--
-- Indices de la tabla `tbl_tipoperfil`
--
ALTER TABLE `tbl_tipoperfil`
  ADD PRIMARY KEY (`Tper_id`);

--
-- Indices de la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  ADD PRIMARY KEY (`usu_id`),
  ADD KEY `per_id` (`per_id`),
  ADD KEY `Tper_id` (`Tper_id`);

--
-- Indices de la tabla `venta`
--
ALTER TABLE `venta`
  ADD PRIMARY KEY (`ven_id`),
  ADD KEY `per_id` (`per_id`),
  ADD KEY `mes_id` (`mes_id`),
  ADD KEY `caj_id` (`caj_id`),
  ADD KEY `suc_id` (`suc_id`);

--
-- Indices de la tabla `ventas_hechas`
--
ALTER TABLE `ventas_hechas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ventas_hechas_ibfk_1` (`pro_id`),
  ADD KEY `ventas_hechas_ibfk_2` (`ven_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `compras`
--
ALTER TABLE `compras`
  MODIFY `id_com` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `compras_vendidos`
--
ALTER TABLE `compras_vendidos`
  MODIFY `id_ven` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `pro_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `productos_hechos`
--
ALTER TABLE `productos_hechos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_caja`
--
ALTER TABLE `tbl_caja`
  MODIFY `caj_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_cargo`
--
ALTER TABLE `tbl_cargo`
  MODIFY `car_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_categoria_insumo`
--
ALTER TABLE `tbl_categoria_insumo`
  MODIFY `catin_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_categoria_producto`
--
ALTER TABLE `tbl_categoria_producto`
  MODIFY `catprod_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_empleado`
--
ALTER TABLE `tbl_empleado`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_insumos`
--
ALTER TABLE `tbl_insumos`
  MODIFY `ins_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_mesa`
--
ALTER TABLE `tbl_mesa`
  MODIFY `mes_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_persona`
--
ALTER TABLE `tbl_persona`
  MODIFY `per_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_productos`
--
ALTER TABLE `tbl_productos`
  MODIFY `pro_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_proveedor`
--
ALTER TABLE `tbl_proveedor`
  MODIFY `prov_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_sucursal`
--
ALTER TABLE `tbl_sucursal`
  MODIFY `suc_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_sueldo`
--
ALTER TABLE `tbl_sueldo`
  MODIFY `suel_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_tipoperfil`
--
ALTER TABLE `tbl_tipoperfil`
  MODIFY `Tper_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  MODIFY `usu_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `venta`
--
ALTER TABLE `venta`
  MODIFY `ven_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ventas_hechas`
--
ALTER TABLE `ventas_hechas`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`usu_id`) REFERENCES `tbl_usuario` (`usu_id`),
  ADD CONSTRAINT `compras_ibfk_2` FOREIGN KEY (`prov_id`) REFERENCES `tbl_proveedor` (`prov_id`);

--
-- Filtros para la tabla `compras_vendidos`
--
ALTER TABLE `compras_vendidos`
  ADD CONSTRAINT `compras_vendidos_ibfk_1` FOREIGN KEY (`ins_id`) REFERENCES `tbl_insumos` (`ins_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `compras_vendidos_ibfk_2` FOREIGN KEY (`id_com`) REFERENCES `compras` (`id_com`) ON DELETE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`suc_id`) REFERENCES `tbl_sucursal` (`suc_id`),
  ADD CONSTRAINT `productos_ibfk_2` FOREIGN KEY (`catpro_id`) REFERENCES `tbl_categoria_producto` (`catprod_id`);

--
-- Filtros para la tabla `productos_hechos`
--
ALTER TABLE `productos_hechos`
  ADD CONSTRAINT `productos_hechos_ibfk_1` FOREIGN KEY (`ins_id`) REFERENCES `tbl_insumos` (`ins_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `productos_hechos_ibfk_2` FOREIGN KEY (`pro_id`) REFERENCES `productos` (`pro_id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `tbl_caja`
--
ALTER TABLE `tbl_caja`
  ADD CONSTRAINT `tbl_caja_ibfk_1` FOREIGN KEY (`suc_id`) REFERENCES `tbl_sucursal` (`suc_id`),
  ADD CONSTRAINT `tbl_caja_ibfk_2` FOREIGN KEY (`suc_id`) REFERENCES `tbl_sucursal` (`suc_id`),
  ADD CONSTRAINT `tbl_caja_ibfk_3` FOREIGN KEY (`suc_id`) REFERENCES `tbl_sucursal` (`suc_id`),
  ADD CONSTRAINT `tbl_caja_ibfk_4` FOREIGN KEY (`suc_id`) REFERENCES `tbl_sucursal` (`suc_id`);

--
-- Filtros para la tabla `tbl_cargo`
--
ALTER TABLE `tbl_cargo`
  ADD CONSTRAINT `tbl_cargo_ibfk_1` FOREIGN KEY (`suc_id`) REFERENCES `tbl_sucursal` (`suc_id`);

--
-- Filtros para la tabla `tbl_empleado`
--
ALTER TABLE `tbl_empleado`
  ADD CONSTRAINT `tbl_empleado_ibfk_1` FOREIGN KEY (`suc_id`) REFERENCES `tbl_sucursal` (`suc_id`),
  ADD CONSTRAINT `tbl_empleado_ibfk_2` FOREIGN KEY (`per_id`) REFERENCES `tbl_persona` (`per_id`),
  ADD CONSTRAINT `tbl_empleado_ibfk_3` FOREIGN KEY (`car_id`) REFERENCES `tbl_cargo` (`car_id`);

--
-- Filtros para la tabla `tbl_insumos`
--
ALTER TABLE `tbl_insumos`
  ADD CONSTRAINT `tbl_insumos_ibfk_1` FOREIGN KEY (`catin_id`) REFERENCES `tbl_categoria_insumo` (`catin_id`),
  ADD CONSTRAINT `tbl_insumos_ibfk_2` FOREIGN KEY (`catin_id`) REFERENCES `tbl_categoria_insumo` (`catin_id`),
  ADD CONSTRAINT `tbl_insumos_ibfk_3` FOREIGN KEY (`catin_id`) REFERENCES `tbl_categoria_insumo` (`catin_id`),
  ADD CONSTRAINT `tbl_insumos_ibfk_4` FOREIGN KEY (`catin_id`) REFERENCES `tbl_categoria_insumo` (`catin_id`);

--
-- Filtros para la tabla `tbl_mesa`
--
ALTER TABLE `tbl_mesa`
  ADD CONSTRAINT `tbl_mesa_ibfk_1` FOREIGN KEY (`suc_id`) REFERENCES `tbl_sucursal` (`suc_id`),
  ADD CONSTRAINT `tbl_mesa_ibfk_2` FOREIGN KEY (`suc_id`) REFERENCES `tbl_sucursal` (`suc_id`),
  ADD CONSTRAINT `tbl_mesa_ibfk_3` FOREIGN KEY (`suc_id`) REFERENCES `tbl_sucursal` (`suc_id`),
  ADD CONSTRAINT `tbl_mesa_ibfk_4` FOREIGN KEY (`suc_id`) REFERENCES `tbl_sucursal` (`suc_id`);

--
-- Filtros para la tabla `tbl_productos`
--
ALTER TABLE `tbl_productos`
  ADD CONSTRAINT `tbl_productos_ibfk_1` FOREIGN KEY (`catprod_id`) REFERENCES `tbl_categoria_producto` (`catprod_id`),
  ADD CONSTRAINT `tbl_productos_ibfk_2` FOREIGN KEY (`catin_id`) REFERENCES `tbl_categoria_insumo` (`catin_id`),
  ADD CONSTRAINT `tbl_productos_ibfk_3` FOREIGN KEY (`ins_id`) REFERENCES `tbl_insumos` (`ins_id`),
  ADD CONSTRAINT `tbl_productos_ibfk_4` FOREIGN KEY (`suc_id`) REFERENCES `tbl_sucursal` (`suc_id`),
  ADD CONSTRAINT `tbl_productos_ibfk_5` FOREIGN KEY (`catin_id`) REFERENCES `tbl_categoria_insumo` (`catin_id`);

--
-- Filtros para la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  ADD CONSTRAINT `tbl_usuario_ibfk_1` FOREIGN KEY (`per_id`) REFERENCES `tbl_persona` (`per_id`),
  ADD CONSTRAINT `tbl_usuario_ibfk_2` FOREIGN KEY (`Tper_id`) REFERENCES `tbl_tipoperfil` (`Tper_id`),
  ADD CONSTRAINT `tbl_usuario_ibfk_3` FOREIGN KEY (`per_id`) REFERENCES `tbl_persona` (`per_id`),
  ADD CONSTRAINT `tbl_usuario_ibfk_4` FOREIGN KEY (`Tper_id`) REFERENCES `tbl_tipoperfil` (`Tper_id`),
  ADD CONSTRAINT `tbl_usuario_ibfk_5` FOREIGN KEY (`per_id`) REFERENCES `tbl_persona` (`per_id`),
  ADD CONSTRAINT `tbl_usuario_ibfk_6` FOREIGN KEY (`Tper_id`) REFERENCES `tbl_tipoperfil` (`Tper_id`),
  ADD CONSTRAINT `tbl_usuario_ibfk_7` FOREIGN KEY (`per_id`) REFERENCES `tbl_persona` (`per_id`),
  ADD CONSTRAINT `tbl_usuario_ibfk_8` FOREIGN KEY (`Tper_id`) REFERENCES `tbl_tipoperfil` (`Tper_id`);

--
-- Filtros para la tabla `venta`
--
ALTER TABLE `venta`
  ADD CONSTRAINT `venta_ibfk_1` FOREIGN KEY (`per_id`) REFERENCES `tbl_persona` (`per_id`),
  ADD CONSTRAINT `venta_ibfk_2` FOREIGN KEY (`mes_id`) REFERENCES `tbl_mesa` (`mes_id`),
  ADD CONSTRAINT `venta_ibfk_3` FOREIGN KEY (`caj_id`) REFERENCES `tbl_caja` (`caj_id`),
  ADD CONSTRAINT `venta_ibfk_4` FOREIGN KEY (`per_id`) REFERENCES `tbl_persona` (`per_id`),
  ADD CONSTRAINT `venta_ibfk_5` FOREIGN KEY (`mes_id`) REFERENCES `tbl_mesa` (`mes_id`),
  ADD CONSTRAINT `venta_ibfk_6` FOREIGN KEY (`caj_id`) REFERENCES `tbl_caja` (`caj_id`),
  ADD CONSTRAINT `venta_ibfk_7` FOREIGN KEY (`suc_id`) REFERENCES `tbl_sucursal` (`suc_id`);

--
-- Filtros para la tabla `ventas_hechas`
--
ALTER TABLE `ventas_hechas`
  ADD CONSTRAINT `ventas_hechas_ibfk_1` FOREIGN KEY (`pro_id`) REFERENCES `productos` (`pro_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ventas_hechas_ibfk_2` FOREIGN KEY (`ven_id`) REFERENCES `venta` (`ven_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
