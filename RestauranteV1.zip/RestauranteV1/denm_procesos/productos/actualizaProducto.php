<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/productos.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['producto'],
	    $_POST['categoria'],
		$_POST['destino'],
        $_POST['stock'],
        $_POST['precio'],
        $_POST['sucursal']
			);

	$obj= new productos();

	echo $obj->actualizaPro($datos);

 ?>