<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/productos.php";

	$obj= new productos;

	echo $obj->eliminaPro($_POST['id']);

 ?>