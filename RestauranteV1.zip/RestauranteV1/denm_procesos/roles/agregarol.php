<?php 
	session_start();
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/conexion1.php";
	require_once "../../denm_clases/roles.php";
	$fecha=date("Y-m-d");
	$conexion=conexion();
	//$idusuario=$_SESSION['iduser'];
	$rol=$_POST['rol'];

	$datos=array(
		$rol);

	$obj= new roles();
    if(buscaRepetido($rol,$conexion)==1){
		echo 2;
	}else{
	echo $obj->agregaRol($datos);
	}

	function buscaRepetido($role,$conexion){
		$sql="SELECT * from tbl_tipoperfil 
			where Tper_desperfil='$role'";
		$result=mysqli_query($conexion,$sql);

		if(mysqli_num_rows($result) > 0){
			return 1;
		}else{
			return 0;
		}
	}

 ?>