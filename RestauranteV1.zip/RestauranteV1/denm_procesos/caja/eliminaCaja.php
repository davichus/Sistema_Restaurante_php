<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/caja.php";

	$obj= new caja;

	echo $obj->eliminaCaja($_POST['id']);

 ?>