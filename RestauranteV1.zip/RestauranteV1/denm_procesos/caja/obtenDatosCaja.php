<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/caja.php";

	$obj= new caja;

	echo json_encode($obj->obtenDatosCaja($_POST['id']));

 ?>