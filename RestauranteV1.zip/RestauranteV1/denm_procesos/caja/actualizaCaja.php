<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/caja.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['suc'],
        $_POST['caja'],
        $_POST['estado']
			);

	$obj= new caja();

	echo $obj->actualizaCaja($datos);

 ?>