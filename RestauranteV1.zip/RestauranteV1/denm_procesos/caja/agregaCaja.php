<?php 
	session_start();
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/caja.php";
	require_once "../../denm_clases/conexion1.php";
    $conexion=conexion();
	$fecha=date("Y-m-d");
	//$idusuario=$_SESSION['iduser'];
	$Esp=$_POST['sl_suc'];
    $caja=$_POST['txt_caja'];
	$datos=array(
        $Esp,
         $caja);

	$obj= new caja();
	//if(buscaRepetido($caja,$conexion)==1){
		//echo 2;
//}else{
	echo $obj->agregaCaja($datos);
//}
function buscaRepetido($ced,$conexion){
	$sql="SELECT * from tbl_caja 
		where caj_desc='$ced'";
	$result=mysqli_query($conexion,$sql);

	if(mysqli_num_rows($result) > 0){
		return 1;
	}else{
		return 0;
	}
}
 ?>