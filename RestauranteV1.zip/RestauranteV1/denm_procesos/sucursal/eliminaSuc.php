<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/sucursal.php";

	$obj= new sucursal;

	echo $obj->eliminaSuc($_POST['id']);

 ?>