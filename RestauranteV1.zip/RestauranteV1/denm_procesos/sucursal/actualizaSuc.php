<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/sucursal.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['nom'],
        $_POST['ruc'],
        $_POST['dir'],
        $_POST['telf'],
        $_POST['correo'],
        $_POST['desc'],
			);

	$obj= new sucursal();

	echo $obj->actualizaSuc($datos);

 ?>