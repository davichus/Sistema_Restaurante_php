<?php 
	session_start();
	require_once "../../denm_clases/conexion.php";

	$c= new conectar();
	$conexion=$c->conexion();

    $idcliente=$_POST['clienteVenta'];
    $codigo=$_POST['codigo'];
	$idproducto=$_POST['sl_insumo'];
	$descripcion=$_POST['unidadV'];
	$cantidad=$_POST['stockV'];
	$precio=$_POST['precioV'];
    $cant=$_POST['cantidadV'];
	$sql="SELECT prov_id,prov_ruc,prov_razon_social 
			from tbl_proveedor 
			where prov_id='$idcliente'";
	$result=mysqli_query($conexion,$sql);

	$c=mysqli_fetch_row($result);

	$ncliente=$c[1]." ".$c[0];

	$sql="SELECT ins_desc 
			from tbl_insumos 
			where ins_id='$idproducto'";
	$result=mysqli_query($conexion,$sql);

	$nombreproducto=mysqli_fetch_row($result)[0];

	$articulo=$idproducto."||".
	            $codigo."||".
				$nombreproducto."||".
				$descripcion."||".
				$precio."||".
				$cant."||".
				$idcliente;

	$_SESSION['tablaComprasTemp'][]=$articulo;

 ?>