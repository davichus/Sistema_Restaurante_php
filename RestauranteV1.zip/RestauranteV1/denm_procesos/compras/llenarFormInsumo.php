<?php 
	
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/compras.php";

	$obj= new compras();

	echo json_encode($obj->obtenDatosInsumo($_POST['idins']))

 ?>