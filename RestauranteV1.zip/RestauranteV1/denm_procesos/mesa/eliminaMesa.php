<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/mesa.php";

	$obj= new mesa;

	echo $obj->eliminaMesa($_POST['id']);

 ?>