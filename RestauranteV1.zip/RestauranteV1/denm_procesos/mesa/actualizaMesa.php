<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/mesa.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['suc'],
        $_POST['mesa'],
        $_POST['sillas']
			);

	$obj= new mesa();

	echo $obj->actualizaMesa($datos);

 ?>