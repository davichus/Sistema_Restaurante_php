<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/persona.php";

	

	$datos=array(
		$_POST['idper'],
        $_POST['ced'],
        $_POST['apepat'],
        $_POST['apemat'],
        $_POST['nom'],
        $_POST['genero'],
        $_POST['fecha'],
        $_POST['telf'],
        $_POST['dir']
			);

	$obj= new persona();

	echo $obj->actualizaPersona($datos);

 ?>