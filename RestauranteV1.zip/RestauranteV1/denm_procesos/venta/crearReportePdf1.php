<?php
include 'plantilla.php';
include_once "../../denm_vistas/base_de_datos.php";
$id=$_GET['ven_id'];
$sentencia = $base_de_datos->query("SELECT venta.ven_id,
venta.ven_codigo, tbl_sucursal.suc_nombre, 
tbl_usuario.usu_correo,
tbl_usuario.usu_nomlogin,
tbl_caja.caj_desc,
tbl_mesa.mes_desc,
venta.ven_efectivo,
venta.ven_visa,
venta.ven_mastercard,
venta.ven_precio,
venta.ven_fecha,
venta.pro_estado,
concat_ws(' ', tbl_persona.per_ced,tbl_persona.per_apepat,tbl_persona.per_apemat,tbl_persona.per_nom) as cliente, 
GROUP_CONCAT( productos.pro_id, '..', productos.pro_desc, '..',productos.pro_precio, '..', ventas_hechas.cantidad SEPARATOR '__') AS productos,
round(venta.ven_precio*0.12,2)as iva,
round(((venta.ven_precio*0.12)+venta.ven_precio),2) as totales 
FROM venta 
INNER JOIN ventas_hechas ON ventas_hechas.ven_id = venta.ven_id 
INNER JOIN productos ON productos.pro_id = ventas_hechas.pro_id 
inner join tbl_usuario on tbl_usuario.usu_id=venta.usu_id 
inner join tbl_persona on tbl_persona.per_id=venta.per_id
INNER join tbl_sucursal on tbl_sucursal.suc_id=venta.suc_id 
inner join tbl_caja on tbl_caja.caj_id=venta.caj_id
inner join tbl_mesa on tbl_mesa.mes_id=venta.mes_id
where venta.ven_id='$id'
GROUP BY venta.ven_id ORDER BY venta.ven_id");
$ventas = $sentencia->fetchAll(PDO::FETCH_OBJ);

$pdf = new PDF();
	$pdf->AliasNbPages();
	$pdf->AddPage();
	
	$pdf->SetFillColor(232,232,232);
	$pdf->SetFont('Arial','B',12);
    
	$pdf->Cell(45,6,'Codigo De Venta:',1,0,'C',1);
	
	$pdf->SetFont('Arial','',10);
    foreach($ventas as $venta){
        $pdf->Cell(30,6,utf8_decode($venta->ven_codigo),1,0,'C');
	    $pdf->SetFont('Arial','B',12);
		$pdf->Cell(20,6,'Fecha:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
        $pdf->Cell(30,6,utf8_decode($venta->ven_fecha),1,0,'C');
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(20,6,'Caja:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(30,6,utf8_decode($venta->caj_desc),1,0,'C');
        $pdf->Ln(8);
        $pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'Sucursal:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(117,6,utf8_decode($venta->suc_nombre),1,0,'C');
		$pdf->SetFont('Arial','B',12);
        $pdf->Ln(8);
        $pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'Cliente:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(117,6,utf8_decode($venta->cliente),1,0,'C');
		$pdf->SetFont('Arial','B',12);
        $pdf->Ln(8);
        $pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'Mesa:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(117,6,utf8_decode($venta->mes_desc),1,0,'C');
		$pdf->SetFont('Arial','B',12);
        $pdf->Ln(8);
        $pdf->SetFont('Arial','B',12);
		$pdf->Cell(80,6,'Pedido',1,0,'C',1); 
        $pdf->Cell(50,6,'Cantidad',1,0,'C',1); 
        $pdf->Cell(45,6,'Precio',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
        

        foreach(explode("__", $venta->productos) as $productosConcatenados){ 
            $producto=explode("..", $productosConcatenados);
            $pdf->Ln(8);
            $pdf->Cell(80,6,utf8_decode($producto[1]),1,0,'C');
            $pdf->Cell(50,6,utf8_decode($producto[3]),1,0,'C');
            $pdf->Cell(45,6,utf8_decode($producto[2]),1,0,'C');
        }
        $pdf->Ln(8);
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(80,6,'',0,0,'C',0); 
		$pdf->Cell(50,6,'Subtotal:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(45,6,utf8_decode($venta->ven_precio),1,0,'C');
        $pdf->Ln(8);
        $pdf->SetFont('Arial','B',12);
		$pdf->Cell(80,6,'',0,0,'C',0); 
		$pdf->Cell(50,6,'Iva 12%:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
        $pdf->Cell(45,6,utf8_decode($venta->ven_precio*0.12),1,0,'C');
        $pdf->Ln(8);
        $pdf->SetFont('Arial','B',12);
		$pdf->Cell(80,6,'',0,0,'C',0); 
		$pdf->Cell(50,6,'Total:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
        $pdf->Cell(45,6,utf8_decode($venta->totales),1,0,'C');
    }

$pdf->Output();
