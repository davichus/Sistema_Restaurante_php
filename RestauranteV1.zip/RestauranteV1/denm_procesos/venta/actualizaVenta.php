<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/venta.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['caja'],
	    $_POST['efectivo'],
		$_POST['visa'],
        $_POST['master'],
        $_POST['total'],
        $_POST['estado']
			);

	$obj= new venta();

	echo $obj->actualizaVen($datos);

 ?>