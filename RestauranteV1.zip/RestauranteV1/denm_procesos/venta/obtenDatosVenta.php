<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/venta.php";

	$obj= new venta;

	echo json_encode($obj->obtenDatosVen($_POST['id']));

 ?>