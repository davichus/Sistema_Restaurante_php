<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/cargos.php";

	$obj= new cargos;

	echo json_encode($obj->obtenDatosCargo($_POST['id']));

 ?>