<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/cargos.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['cargo'],
        $_POST['suc']
			);

	$obj= new cargos();

	echo $obj->actualizaCargo($datos);

 ?>