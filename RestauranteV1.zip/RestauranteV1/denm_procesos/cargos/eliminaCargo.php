<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/cargos.php";

	$obj= new cargos;

	echo $obj->eliminaCargo($_POST['id']);

 ?>