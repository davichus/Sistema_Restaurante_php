<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/empleados.php";

	$obj= new empleados;

	echo $obj->eliminaEmp($_POST['id']);

 ?>