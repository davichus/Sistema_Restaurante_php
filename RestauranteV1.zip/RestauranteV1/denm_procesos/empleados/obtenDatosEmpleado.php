<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/empleados.php";

	$obj= new empleados;

	echo json_encode($obj->obtenDatoseEmp($_POST['id']));

 ?>