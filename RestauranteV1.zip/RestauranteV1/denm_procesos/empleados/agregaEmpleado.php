<?php 


	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/empleados.php";
	require_once "../../denm_clases/conexion1.php";

    $conexion=conexion();

	$obj= new empleados();
    
     
	$datos=array(
            $_POST['sl_persona'],
			$_POST['sl_centro'],
			$_POST['sl_medico']
          
				);
     //if(buscaRepetido($_POST['txt_cedula'],$conexion)==1){
					//echo 2;
	//}else{
	echo $obj->agregaEmp($datos);
	
//}
	
	function buscaRepetido($ced,$conexion){
		$sql="SELECT * from tbl_persona 
			where per_ced='$ced'";
		$result=mysqli_query($conexion,$sql);

		if(mysqli_num_rows($result) > 0){
			return 1;
		}else{
			return 0;
		}
	}
	
 ?>