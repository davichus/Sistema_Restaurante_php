<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/categoria_insumo.php";

	

	$datos=array(
		$_POST['id'],
		$_POST['cat']
			);

	$obj= new categoria_insumo();

	echo $obj->actualizaCatin($datos);

 ?>