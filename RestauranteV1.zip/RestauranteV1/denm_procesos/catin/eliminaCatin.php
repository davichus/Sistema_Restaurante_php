<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/categoria_insumo.php";

	$obj= new categoria_insumo;

	echo $obj->eliminaCatin($_POST['idcat']);

 ?>