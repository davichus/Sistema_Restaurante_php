<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/categoria_producto.php";

	$obj= new categoria_producto;

	echo $obj->eliminaCatin($_POST['idpro']);

 ?>