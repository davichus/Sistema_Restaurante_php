<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/categoria_producto.php";

	

	$datos=array(
		$_POST['id'],
		$_POST['pro']
			);

	$obj= new categoria_producto();

	echo $obj->actualiza($datos);

 ?>