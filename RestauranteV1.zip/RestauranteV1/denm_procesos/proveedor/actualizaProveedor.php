<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/proveedor.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['cedula'],
        $_POST['ruc'],
        $_POST['razon'],
        $_POST['direccion'],
        $_POST['telefono'],
        $_POST['correo'],
        $_POST['cta'],
        $_POST['ctaa'],
        $_POST['ob']
			);

	$obj= new proveedor();

	echo $obj->actualizaProv($datos);

 ?>