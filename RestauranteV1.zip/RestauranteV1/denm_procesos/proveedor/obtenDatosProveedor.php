<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/proveedor.php";

	$obj= new proveedor;

	echo json_encode($obj->obtenDatosProv($_POST['id']));

 ?>