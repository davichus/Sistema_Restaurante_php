<?php 
	session_start();
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/proveedor.php";
	require_once "../../denm_clases/conexion1.php";
    $conexion=conexion();
    $obj= new proveedor();
	$datos=array(
        $_POST['txt_cedula'],
	$_POST['txt_ruc'],
	$_POST['txt_razon'],
	$_POST['txt_direccion'],
	$_POST['txt_telefono'],
	$_POST['txt_correo'],
	$_POST['txt_cta'],
	$_POST['txt_ctaa'],
    $_POST['txt_ob']
                );

	
if(buscaRepetido($_POST['txt_ruc'],$conexion)==1){
		echo 2;
}else{
	echo $obj->agregaProv($datos);
}
function buscaRepetido($ced,$conexion){
	$sql="SELECT * from tbl_proveedor 
		where prov_ruc='$ced'";
	$result=mysqli_query($conexion,$sql);

	if(mysqli_num_rows($result) > 0){
		return 1;
	}else{
		return 0;
	}
}
 ?>