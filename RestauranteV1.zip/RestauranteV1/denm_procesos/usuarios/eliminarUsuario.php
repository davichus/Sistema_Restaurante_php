<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/usuarios.php";

	$obj= new usuarios;

	echo $obj->eliminaUsuario($_POST['id']);

 ?>