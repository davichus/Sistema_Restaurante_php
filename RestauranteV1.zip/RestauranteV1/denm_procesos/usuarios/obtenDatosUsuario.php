<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/usuarios.php";

	$obj= new usuarios;

	echo json_encode($obj->obtenDatosUsuario($_POST['id']));

 ?>