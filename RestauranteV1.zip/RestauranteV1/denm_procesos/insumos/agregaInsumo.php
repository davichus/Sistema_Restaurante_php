<?php 


	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/insumos.php";
	require_once "../../denm_clases/conexion1.php";

    $conexion=conexion();

	$obj= new insumos();
    
     
	$datos=array(
            $_POST['txt_caja'],
			$_POST['sl_tipo'],
			$_POST['sl_insumo'],
            $_POST['sl_medida'],
            $_POST['txt_cantidad'],
            $_POST['txt_stock'],
			$_POST['txt_medidas'],
			$_POST['txt_precio']
				);
     if(buscaRepetido($_POST['txt_caja'],$conexion)==1){
					echo 2;
	}else{
	echo $obj->agregaIns($datos);
	
}
	
	function buscaRepetido($ced,$conexion){
		$sql="SELECT * from tbl_insumos 
			where ins_desc='$ced'";
		$result=mysqli_query($conexion,$sql);

		if(mysqli_num_rows($result) > 0){
			return 1;
		}else{
			return 0;
		}
	}
	
 ?>