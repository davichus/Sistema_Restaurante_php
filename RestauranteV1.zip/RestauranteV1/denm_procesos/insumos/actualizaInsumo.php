<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/insumos.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['caja'],
	    $_POST['tipo'],
		$_POST['insumo'],
        $_POST['medida'],
        $_POST['cantidad'],
        $_POST['stock'],
		$_POST['medidas'],
		$_POST['precio']
			);

	$obj= new insumos();

	echo $obj->actualizaIn($datos);

 ?>