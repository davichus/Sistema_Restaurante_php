<?php 
session_start();
if(isset($_SESSION['usuario']) and $_SESSION['rol']=='1' or $_SESSION['rol']=="3"){
	?>

<?php
include_once "menu.php";
include_once "base_de_datos.php";
$sentencia = $base_de_datos->query("SELECT productos.pro_id,productos.pro_precio, tbl_categoria_producto.catprod_desc, productos.pro_desc , productos.pro_destino, productos.pro_stock, tbl_sucursal.suc_nombre, GROUP_CONCAT( tbl_insumos.ins_id, '..', tbl_insumos.ins_desc, '..',tbl_insumos.ins_precio, '..', productos_hechos.cantidad SEPARATOR '__') AS productos FROM productos INNER JOIN productos_hechos ON productos_hechos.pro_id = productos.pro_id INNER JOIN tbl_insumos ON tbl_insumos.ins_id = productos_hechos.ins_id INNER JOIN tbl_categoria_producto on tbl_categoria_producto.catprod_id=productos.catpro_id INNER join tbl_sucursal on tbl_sucursal.suc_id=productos.suc_id where productos.pro_estado='A' GROUP BY productos.pro_id ORDER BY productos_hechos.pro_id");
$ventas = $sentencia->fetchAll(PDO::FETCH_OBJ);
?>
 <?php require_once "../denm_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
        ?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<h1>Productos</h1>
		<div>
			<a class="btn btn-success" href="./productos.php">Nueva <i class="fa fa-plus"></i></a>
		</div>
		<br>
		<table class="table table-bordered">
			<thead>
				<tr>
                    <th>Categoria</th>
                    <th>Producto</th>
					<th>Destino</th>
                    <th>Stock</th>
                    <th>Insumos</th>
					<th>Totales</th>
					<th colspan="2">Acciones</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($ventas as $venta){ ?>
				<tr>
                    <td><?php echo $venta->catprod_desc ?></td>
                    <td><?php echo $venta->pro_desc ?></td>
                    <td><?php echo $venta->pro_destino ?></td>
                    <td><?php echo $venta->pro_stock ?></td>
					<td>
						<table class="table table-bordered">
							<thead>
								<tr>
									
									<th>Insumo</th>
                                    <th>Cantidad</th>
                                    <th>Precio</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach(explode("__", $venta->productos) as $productosConcatenados){ 
								$producto = explode("..", $productosConcatenados)
								?>
								<tr>
	
									<td><?php echo $producto[1] ?></td>
                                    <td><?php echo $producto[3] ?></td>
                                    <td><?php echo $producto[2] ?></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
					</td>
                    <td><b>Total:</b> <?php echo $venta->pro_precio ?> <br>
					<td>
			<span  data-toggle="modal" data-target="#actualizaPro" class="btn btn-warning" onclick="agregaDato('<?php echo $venta->pro_id ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
                </td>
					<td><span class="btn btn-danger " onclick="eliminarProv('<?php echo $venta->pro_id ?>')">
				<span class="glyphicon glyphicon-remove"></span></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
	<div class="modal fade" id="actualizaPro" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualizar Venta</h4>
					</div>
					<div class="modal-body">
						<form id="frmPersonaU" name="frmPersonaU">
                        <input type="text" hidden="" id="id" name="id">
                        <label>Producto</label>
						<input type="text" class="form-control input-sm" name="producto" id="producto">
						<label>Categoria Producto</label>
                        <select class="form-control input-sm" id="categoria" name="categoria">
				               <option value="0">--Seleccione--</option>
				<?php
				$sql="SELECT catprod_id,
			     catprod_desc
				from tbl_categoria_producto";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
			</select>
			<label>Destino</label>
							<br>
							<select name="destino" class="form-control input-sm" id="destino" required>
                          <option value="" disabled selected hidden>--Seleccione--</option>
                          <option value="Cocina">Cocina</option>
                          <option value="Bar">Bar</option>
                     
                         
                       
                          </select>

            <label>Stock</label>
			<input type="number" class="form-control input-sm" id="stock" name="stock"   style="width : 60px; heigth : 1px">
            <label>Precio</label>
			<input type="text" class="form-control input-sm" id="precio" name="precio"   style="width : 60px; heigth : 1px">           
			<label>Sucursal</label>
                        <select class="form-control input-sm" id="sucursal" name="sucursal">
				               <option value="0">--Seleccione--</option>
				<?php
				$sql="SELECT suc_id,
			     suc_nombre
				from tbl_sucursal";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
			</select>
                    
                      
							
						</form>
					</div>
					<div class="modal-footer">
						<button id="btnAgregarPersonaU" type="button" class="btn btn-primary" data-dismiss="modal">Actualizar</button>

					</div>
				</div>
			</div>
		</div>
		
	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnAgregarPersonaU').click(function(){

				datos=$('#frmPersonaU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/productos/actualizaProducto.php",
					success:function(r){
						if(r==1){
                            
							alertify.success("Actualizado con exito !!");
							window.location="ProductosHechos.php";
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
			function agregaDato(id){

                $.ajax({
                            type:"POST",
                            data:"id=" + id,
                            url:"../denm_procesos/productos/obtenDatosProducto.php",
                        success:function(r){
                        dato=jQuery.parseJSON(r);

                        $('#id').val(dato['pro_id']);
                        $('#producto').val(dato['pro_desc']);
                        $('#categoria').val(dato['catpro_id']);
                        $('#destino').val(dato['pro_destino']);
                        $('#stock').val(dato['pro_stock']);
                        $('#precio').val(dato['pro_precio']);
                        $('#sucursal').val(dato['suc_id']);
                       
}
});
}

		function eliminarProv(idper){
			alertify.confirm('¿Desea eliminar este Producto?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + idper,
					url:"../denm_procesos/productos/eliminaProducto.php",
					success:function(r){
						if(r==1){
                            
							alertify.success("Eliminado con exito!!");
							window.location="ProductosHechos.php";
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
    






    <?php 
}else{
	header("location:../index.php");
}
?>