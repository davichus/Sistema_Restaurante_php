<?php
include 'db.php';
$id = $_POST["id"];

$estadosdb = ModeloPaises::mdlTraerDependencias($id);

foreach ($estadosdb as $key => $value) {
	echo '<option value="'.$value["car_id"].'">'.$value["car_desc"].'</option>';
}