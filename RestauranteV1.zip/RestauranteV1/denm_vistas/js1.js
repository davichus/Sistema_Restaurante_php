function selectpaises1() {
	var id_pais = $("#selectpaisesid").val();
	$.ajax({
		url: "select1.ajax.php",
		method: "POST",
		data: {
			"id":id_pais
		},
		success: function(respuesta){
			$("#selectestado").attr("disabled", false);
			$("#selectestado").html(respuesta);
		}
	})
}