<?php
if(!isset($_POST["total"]) && !isset($_POST["venta"]) && !isset($_POST["cliente"]) && !isset($_POST["sucursal"])&& !isset($_POST["caja"]) && !isset($_POST["mesa"])) exit;


session_start();
$usu=$_SESSION['iduser'];
$venta=$_POST["venta"];
$cliente=$_POST["cliente"];
$sucursal=$_POST["sucursal"];
$caja=$_POST["caja"];
$mesa=$_POST["mesa"];
$total = $_POST["total"];

include_once "base_de_datos.php";

$codigo=$venta+1;
$ahora =date('Y-m-d');
$fecha=date('Y-m-d',strtotime($ahora."- 1 days"));
$estado="Pendiente";
$efectivo="0";
$visa="0";
$master="0";

$sentencia = $base_de_datos->prepare("INSERT INTO venta(ven_codigo,usu_id,per_id,suc_id,caj_id,mes_id,ven_efectivo,ven_visa,ven_mastercard,ven_precio,ven_fecha,pro_estado) VALUES (?,?,?,?,?,?,?,?,?,?,?,?);");
$sentencia->execute([$venta,$usu,$cliente,$sucursal,$caja,$mesa,$efectivo,$visa,$master,$total,$ahora,$estado]);

$sentencia = $base_de_datos->prepare("SELECT ven_id FROM venta ORDER BY ven_id DESC LIMIT 1;");
$sentencia->execute();
$resultado = $sentencia->fetch(PDO::FETCH_OBJ);

$idVenta = $resultado === false ? 1 : $resultado->ven_id;

$base_de_datos->beginTransaction();
$sentencia = $base_de_datos->prepare("INSERT INTO ventas_hechas(pro_id, ven_id, cantidad) VALUES (?, ?, ?);");
$sentenciaExistencia = $base_de_datos->prepare("UPDATE productos SET pro_stock = pro_stock - ? WHERE pro_id = ?;");
foreach ($_SESSION["carrito"] as $producto) {
	$total += $producto->total;
	$sentencia->execute([$producto->pro_id, $idVenta, $producto->pro_stock]);
	$sentenciaExistencia->execute([$producto->pro_stock, $producto->pro_id]);
}
$base_de_datos->commit();
unset($_SESSION["carrito"]);
$_SESSION["carrito"] = [];
header("Location: ./ventas.php?status=1");
?>