<?php 
session_start();
if(isset($_SESSION['usuario'])){

	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Restaurante/Bar</title>
        <?php require_once "menu.php"; ?>
        <?php require_once "../denm_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
        ?>
       
        <script>
//Función que realiza la suma
     function Suma() {
   var ingreso1 = document.frmPersona.txt_cantidad.value;
   var ingreso2 = document.frmPersona.txt_stock.value;
   try{
      //Calculamos el número escrito:
       ingreso1 = (isNaN(parseFloat(ingreso1)))? 0 : parseFloat(ingreso1);
       ingreso2 = (isNaN(parseFloat(ingreso2)))? 0 : parseFloat(ingreso2);
       document.frmPersona.txt_medidas.value = ingreso1*ingreso2;
   }
   //Si se produce un error no hacemos nada
   catch(e) {}
   }
   
</script>
<script>
//Función que realiza la suma
     function Suma1() {
   var ingreso1 = document.frmPersonaU.cantidad.value;
   var ingreso2 = document.frmPersonaU.stock.value;
   try{
      //Calculamos el número escrito:
       ingreso1 = (isNaN(parseFloat(ingreso1)))? 0 : parseFloat(ingreso1);
       ingreso2 = (isNaN(parseFloat(ingreso2)))? 0 : parseFloat(ingreso2);
       document.frmPersonaU.medidas.value = ingreso1*ingreso2;
   }
   //Si se produce un error no hacemos nada
   catch(e) {}
   }
   
</script>


	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <h1>Comprar Insumnos</h1>
		 <div class="row">
		 	<div class="col-sm-12">
			
		 		<span class="btn btn-default" id="ventaProductosBtn">Comprar Insumos</span>
		 		<span class="btn btn-default" id="ventasHechasBtn">Compras Hechas</span>
		 	</div>
		 </div>
		 <div class="row">
		 	<div class="col-sm-12">
		 		<div id="ventaProductos"></div>
		 		<div id="ventasHechas"></div>
		 	</div>
		 </div>
	</div>
		</div>

	

	</body>
    </html>
  
    <script type="text/javascript">
		$(document).ready(function(){
			$('#ventaProductosBtn').click(function(){
				esconderSeccionVenta();
				$('#ventaProductos').load('compras/comprasdeInsumos.php');
				$('#ventaProductos').show();
			});
			$('#ventasHechasBtn').click(function(){
				esconderSeccionVenta();
				$('#ventasHechas').load('ventas/ventasyReportes.php');
				$('#ventasHechas').show();
			});
		});

		function esconderSeccionVenta(){
			$('#ventaProductos').hide();
			$('#ventasHechas').hide();
		}

	</script>
    

   
	
	
<?php 
}else{
	header("location:../index.php");
}
?>