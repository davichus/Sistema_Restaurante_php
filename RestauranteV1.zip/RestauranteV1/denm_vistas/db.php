<?php

class Conexion{
	static public function conectar()
	{
		$link = new PDO("mysql:host=localhost;dbname=restaurante",
						"root",
						"");
		$link->exec("set names utf8");

		return $link;
	}
}

/**
 * 

 */
class ModeloPaises
{
	
	static public function mdlShowPaises(){

		$stmt = Conexion::conectar()->prepare("SELECT * FROM tbl_sucursal");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

		$stmt = null;
	}

	static public function mdlTraerDependencias($id_pais){

		$stmt = Conexion::conectar()->prepare("SELECT *from tbl_cargo
		WHERE suc_id = $id_pais");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

		$stmt = null;
	}
}



?>