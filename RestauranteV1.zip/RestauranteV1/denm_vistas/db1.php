<?php

class Conexion1{
	static public function conectar()
	{
		$link = new PDO("mysql:host=localhost;dbname=restaurante",
						"root",
						"");
		$link->exec("set names utf8");

		return $link;
	}
}

/**
 * 

 */
class ModeloPaises1
{
	
	static public function mdlShowPaises(){

		$stmt = Conexion1::conectar()->prepare("SELECT *from tbl_categoria_producto");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

		$stmt = null;
		//SELECT *from tbl_insumos
		//SELECT * FROM tbl_categoria_producto
	}

	static public function mdlTraerDependencias($id_pais){

		$stmt = Conexion1::conectar()->prepare("SELECT * FROM productos
		WHERE catpro_id = $id_pais");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

		$stmt = null;
	}
}



?>