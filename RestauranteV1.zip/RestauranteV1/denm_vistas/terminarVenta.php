
<?php
if(!isset($_POST["total"]) && !isset($_POST["sl_proveedor"]) && !isset($_POST["codigo"]) ) exit;


session_start();

$prov=$_POST["sl_proveedor"];
$codigo=$_POST["codigo"];
$usu=$_SESSION['iduser'];
$total = $_POST["total"];
include_once "base_de_datos.php";


$ahora = date("Y-m-d H:i:s");


$sentencia = $base_de_datos->prepare("INSERT INTO compras(usu_id,prov_id,codigo,fecha,total) VALUES (?,?,?,?,?);");
$sentencia->execute([$usu,$prov,$codigo,$ahora,$total]);

$sentencia = $base_de_datos->prepare("SELECT id_com FROM compras ORDER BY id_com DESC LIMIT 1;");
$sentencia->execute();
$resultado = $sentencia->fetch(PDO::FETCH_OBJ);

$idVenta = $resultado === false ? 1 : $resultado->id_com;

$base_de_datos->beginTransaction();
$sentencia = $base_de_datos->prepare("INSERT INTO compras_vendidos(ins_id, id_com, cantidad) VALUES (?, ?, ?);");
$sentenciaExistencia = $base_de_datos->prepare("UPDATE tbl_insumos SET ins_stock = ins_stock - ? WHERE ins_id = ?;");
foreach ($_SESSION["carrito"] as $producto) {
	$total += $producto->total;
	$sentencia->execute([$producto->ins_id, $idVenta, $producto->ins_stock]);
	$sentenciaExistencia->execute([$producto->ins_stock, $producto->ins_id]);
}
$base_de_datos->commit();
unset($_SESSION["carrito"]);
$_SESSION["carrito"] = [];
header("Location: ./comprar.php?status=1");
?>