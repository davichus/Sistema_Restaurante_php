<?php 
session_start();
if(isset($_SESSION['usuario']) and $_SESSION['rol']=='1'){
	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Citas Medicas</title>
        <?php require_once "menu.php"; ?>
        <?php require_once "../denm_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
		?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Administrar usuarios</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmRegistro">
                        
                    <label>Persona</label>
						<select class="form-control input-sm" id="sl_persona" name="sl_persona">
							<option value="">--Seleccione--</option>
							<?php while($ver=mysqli_fetch_row($result)): ?>
								<option value="<?php echo $ver[0] ?>"><?php echo $ver[1]; ?> <?php echo $ver[2]; ?> <?php echo $ver[3]; ?> <?php echo $ver[4]; ?></option>
							<?php endwhile; ?>
						</select>
                    
                    
                    <label>Correo</label>
						<input type="email" class="form-control input-sm" name="txt_correo" id="txt_correo">
						<label>Usuario</label>
						<input type="text" class="form-control input-sm" name="txt_usuario" id="txt_usuario">
			
						<label>Password</label>
						<input type="password" class="form-control input-sm" name="txt_pass" id="txt_pass">
                        <label>Rol</label>
			<select class="form-control input-sm" id="sl_rol" name="sl_rol">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT Tper_id,
				Tper_desperfil
				from tbl_tipoperfil";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
			</select>
                        
						<p></p>
						<center><span class="btn btn-primary" id="registro">Registrar Usuario</span></center>

					</form>
				</div>
				<div class="col-sm-7">
					<div id="tablaUsuariosLoad"></div>
				</div>
			</div>
		</div>


		<!-- Button trigger modal -->


		<!-- Modal -->
		<div class="modal fade" id="actualizaUsuarioModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualiza Usuario</h4>
					</div>
					<div class="modal-body">
						<form id="frmRegistroU">
							<input type="text" hidden="" id="id" name="id">
							<label>Correo</label>
							<input type="email" class="form-control input-sm" name="correo" id="correo">
							<label>Usuario</label>
							<input type="text" class="form-control input-sm" name="usu" id="usu">
							<label>Contraseña</label>
							<input type="text" class="form-control input-sm" name="pass" id="pass">
							
							<label>Rol</label>
			<select class="form-control input-sm" id="rol" name="rol">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT Tper_id,
				Tper_desperfil
				from tbl_tipoperfil";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
			</select>
							

						</form>
					</div>
					<div class="modal-footer">
						<button id="btnActualizaUsuario" type="button" class="btn btn-warning" data-dismiss="modal">Actualiza Usuario</button>

					</div>
				</div>
			</div>
		</div>

	</body>
	</html>

	<script type="text/javascript">
		function agregaDatosUsuario(id){

			$.ajax({
				type:"POST",
				data:"id=" + id,
				url:"../denm_procesos/usuarios/obtenDatosUsuario.php",
				success:function(r){
					dato=jQuery.parseJSON(r);

					$('#id').val(dato['usu_id']);
					$('#correo').val(dato['usu_correo']);
					$('#usu').val(dato['usu_nomlogin']);
					$('#pass').val(dato['usu_pass']);
					$('#rol').val(dato['Tper_id']);
					
				}
			});
		}

		function eliminarUsuario(idusuario){
			alertify.confirm('¿Desea eliminar este usuario?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + idusuario,
					url:"../denm_procesos/usuarios/eliminarUsuario.php",
					success:function(r){
						
						 if(r==1){
							$('#tablaUsuariosLoad').load('usuarios/tablaUsuarios.php');
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar :(");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}


	</script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnActualizaUsuario').click(function(){

				datos=$('#frmRegistroU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/usuarios/actualizaUsuario.php",
					success:function(r){

						if(r==1){
							$('#tablaUsuariosLoad').load('usuarios/tablaUsuarios.php');
							alertify.success("Actualizado con exito :D");
						}else{
							alertify.error("No se pudo actualizar");
						}
					}
				});
			});
		});
	</script>

	<script type="text/javascript">
		$(document).ready(function(){

			$('#tablaUsuariosLoad').load('usuarios/tablaUsuarios.php');

			$('#registro').click(function(){

				vacios=validarFormVacio('frmRegistro');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmRegistro').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/reglogin/registrarUsuario.php",
					success:function(r){
						//alert(r);
                        if(r==2){
							$('#tablaUsuariosLoad').load('usuarios/tablaUsuarios.php');
								alertify.alert("Este Usuario y Correo Electronico ya existe, prueba con otro!!");
							}
						
						else if(r==1){
							$('#frmRegistro')[0].reset();
							$('#tablaUsuariosLoad').load('usuarios/tablaUsuarios.php');
							alertify.success("Agregado con exito");
						}else{
							alertify.error("Fallo al agregar :(");
						}
					}
				});
			});
		});
	</script>
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
	<?php 
}else{
	header("location:../index.php");
}
?>