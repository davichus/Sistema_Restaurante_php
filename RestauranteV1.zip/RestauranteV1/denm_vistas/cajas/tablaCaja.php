<?php 
			require_once "../../denm_clases/conexion.php";
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="SELECT c.caj_id,
                         s.suc_nombre,
                         c.caj_desc,
                         c.caj_estado
                    FROM tbl_caja c
                    inner join tbl_sucursal s on c.suc_id=s.suc_id";
			$result=mysqli_query($conexion,$sql);
	 ?>


<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><label>Cajas</label></caption>
	<tr>
        <td>Sucursal</td>
        <td>Caja No</td>
		<td>Estado</td>
		<td colspan="2">Aciones</td>
		
	</tr>

	<?php
	while ($ver=mysqli_fetch_row($result)):
	 ?>

	<tr>
		<td><?php echo $ver[1] ?></td>
        <td><?php echo $ver[2] ?></td>
        <?php
		if($ver[3]=='Cerrada'){
			echo '<td class="btn btn-danger btn-xs">'.$ver[3].'</td>';
		}
		else{
			echo '<td class="btn btn-success btn-xs">'.$ver[3].'</td>';
		  }
		  
		
		?>
		<td>
		<span  data-toggle="modal" data-target="#actualizaCaja" class="btn btn-warning btn-xs" onclick="agregaDato('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
		<td>
			<span class="btn btn-danger btn-xs" onclick="eliminaEsp('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-remove"></span>
			</span>
		</td>
	</tr>

<?php endwhile; ?>
</table>