
<?php
if(!isset($_POST["total"]) && !isset($_POST["cate"]) && !isset($_POST["producto"]) && !isset($_POST["destino"])&& !isset($_POST["stock"]) && !isset($_POST["precio"])&& !isset($_POST["sl_sucursal"])) exit;


session_start();
$nombre=$_POST["producto"];
$cate=$_POST["cate"];
$destino=$_POST["destino"];
$stock=$_POST["stock"];
$precio=$_POST["precio"];
$sucursal = $_POST["sl_sucursal"];
$total = $_POST["total"];

include_once "base_de_datos.php";


$ahora = date("Y-m-d H:i:s");
$estado="A";

$sentencia = $base_de_datos->prepare("INSERT INTO productos(pro_desc,catpro_id,pro_destino,pro_stock,pro_precio,suc_id,pro_estado) VALUES (?,?,?,?,?,?,?);");
$sentencia->execute([$nombre,$cate,$destino,$stock,$precio,$sucursal,$estado]);

$sentencia = $base_de_datos->prepare("SELECT pro_id FROM productos ORDER BY pro_id DESC LIMIT 1;");
$sentencia->execute();
$resultado = $sentencia->fetch(PDO::FETCH_OBJ);

$idVenta = $resultado === false ? 1 : $resultado->pro_id;

$base_de_datos->beginTransaction();
$sentencia = $base_de_datos->prepare("INSERT INTO productos_hechos(ins_id, pro_id, cantidad) VALUES (?, ?, ?);");
$sentenciaExistencia = $base_de_datos->prepare("UPDATE tbl_insumos SET ins_stock = ins_stock - ? WHERE ins_id = ?;");
foreach ($_SESSION["carrito"] as $producto) {
	$total += $producto->total;
	$sentencia->execute([$producto->ins_id, $idVenta, $producto->ins_stock]);
	$sentenciaExistencia->execute([$producto->ins_stock, $producto->ins_id]);
}
$base_de_datos->commit();
unset($_SESSION["carrito"]);
$_SESSION["carrito"] = [];
header("Location: ./productos.php?status=1");
?>