<?php 
	
	require_once "../../denm_clases/conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();

	$sql="SELECT *FROM tbl_proveedor where prov_estado='A'";
	$result=mysqli_query($conexion,$sql);

 ?>


<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><center><label>Proveedores Registrados</label></center></caption>
	<tr>
		<td>Cedula</td>
		<td>Ruc</td>
		<td>Razon Social</td>
        <td>Direccion</td>
        <td>Telefono</td>
        <td>Email</td>
        <td>Cuentas</td>
        <td>Observacion</td>
        <td>Estado</td>
		<td colspan="2">Acciones</td>
	
	</tr>

	<?php while($ver=mysqli_fetch_row($result)): ?>

	<tr>
		<td><?php echo $ver[1]; ?></td>
		<td><?php echo $ver[2]; ?></td>
		<td><?php echo $ver[3]; ?></td>
        <td><?php echo $ver[4]; ?></td>
        <td><?php echo $ver[5]; ?></td>
        <td><?php echo $ver[6]; ?></td>
        <td><b>Cuenta No.1</b> <?php echo $ver[7]; ?> <b>Cuenta No.2</b> <?php echo $ver[8]; ?></td>
        <td><?php echo $ver[9]; ?></td>
        <td><?php echo $ver[10]; ?></td>
		<td>
		<span  data-toggle="modal" data-target="#abremodalPersonaUpdate" class="btn btn-warning btn-xs" onclick="agregaDato('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
		<td>
			<span class="btn btn-danger btn-xs" onclick="eliminarProv('<?php echo $ver[0]; ?>')">
				<span class="glyphicon glyphicon-remove"></span>
			</span>
		</td>
	</tr>
<?php endwhile; ?>
</table>