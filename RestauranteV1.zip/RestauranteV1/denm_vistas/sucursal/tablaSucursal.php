<?php 
	require_once "../../denm_clases/conexion.php";

	$obj= new conectar();
	$conexion= $obj->conexion();

	$sql="SELECT *
		from tbl_sucursal where suc_estado='A'";
	$result=mysqli_query($conexion,$sql);
 ?>

<div class="table-responsive">
	 <table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	 	<caption><center><label><b>Sucursales</label></center></caption>
	 	<tr >
            <td ><b>Sucursal</td>
             <td ><b>Ruc</td>
             <td><b>Direccion</td>
	 		<td><b>Telefono</td>
             <td><b>Correo</td>
             <td><b>Descripcion</td>
           
	 		<td><b>Estado</td>
	 		
	 		<td colspan="2"> <b>Acciones</td>
	 		
	 	</tr>

	 	<?php while($ver=mysqli_fetch_row($result)): ?>

	 	<tr>
            <td><?php echo $ver[1]; ?></td>
	 		<td><?php echo $ver[2]; ?></td>
	 		
	 		<td><?php echo $ver[3]; ?></td>
	 		<td><?php echo $ver[4]; ?></td>
	 		
             <td><?php echo $ver[5]; ?></td>
             <td><?php echo $ver[6]; ?></td>
             <td><?php echo $ver[7]; ?></td>
          
	 		<td>
                <span class="btn btn-warning btn-xs" data-toggle="modal" data-target="#abremodalCentroUpdate" onclick="agregaDatosCentro('<?php echo $ver[0]; ?>','<?php echo $ver[1] ?>'
                ,'<?php echo $ver[2] ?>','<?php echo $ver[3] ?>','<?php echo $ver[4] ?>','<?php echo $ver[5] ?>','<?php echo $ver[6] ?>','<?php echo $ver[7] ?>')">
					<span class="glyphicon glyphicon-pencil"></span>
				</span>
			</td>
			<td>
				<span class="btn btn-danger btn-xs" onclick="eliminarCentro('<?php echo $ver[0]; ?>')">
					<span class="glyphicon glyphicon-remove"></span>
				</span>
			</td>
	 	</tr>
	 <?php endwhile; ?>
	 </table>
</div>