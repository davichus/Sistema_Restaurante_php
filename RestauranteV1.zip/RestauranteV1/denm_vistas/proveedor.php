<?php 
session_start();
if(isset($_SESSION['usuario'])){

	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Restaurante/Bar</title>
		<?php require_once "menu.php"; ?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Registro Proveedores</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmPersona">
					    <label>Cedula</label>
						<input type="text" class="form-control input-sm" id="txt_cedula" name="txt_cedula" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Ruc</label>
						<input type="text" class="form-control input-sm" id="txt_ruc" name="txt_ruc" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Razon Social</label>
						<input type="text" class="form-control input-sm" id="txt_razon" name="txt_razon" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Direccion</label>
						<input type="text" class="form-control input-sm" id="txt_direccion" name="txt_direccion">
                        <label>Telefono</label>
						<input type="text" class="form-control input-sm" id="txt_telefono" name="txt_telefono" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Correo Electronico</label>
						<input type="email" class="form-control input-sm" id="txt_correo" name="txt_correo">
                        
                        <label>Cuenta No1.</label>
                        <input type="text" class="form-control input-sm" id="txt_cta" name="txt_cta" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Cuanta No2.</label>
						<input type="text" class="form-control input-sm" id="txt_ctaa" name="txt_ctaa" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">

                        <label>Observaciones</label>
						<textarea  id="txt_ob" name="txt_ob" class="form-control input-sm"></textarea>
                        
						<p></p>
						<span class="btn btn-primary" id="btnAgregarPersona">Agregar</span>
					</form>
				</div>
				<div class="col-sm-8">
					<div id="tablaPersonaLoad"></div>
				</div>
			</div>
		</div>

		<!-- Button trigger modal -->


		<!-- Modal -->
		<div class="modal fade" id="abremodalPersonaUpdate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualizar Proveedor</h4>
					</div>
					<div class="modal-body">
						<form id="frmPersonaU">
                        <input type="text" hidden="" id="id" name="id">

                        <label>Cedula</label>
						<input type="text" class="form-control input-sm" id="cedula" name="cedula" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Ruc</label>
						<input type="text" class="form-control input-sm" id="ruc" name="ruc" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Razon Social</label>
						<input type="text" class="form-control input-sm" id="razon" name="razon" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Direccion</label>
						<input type="text" class="form-control input-sm" id="direccion" name="direccion">
                        <label>Telefono</label>
						<input type="text" class="form-control input-sm" id="telefono" name="telefono" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Correo Electronico</label>
						<input type="email" class="form-control input-sm" id="correo" name="correo">
                        
                        <label>Cuenta No1.</label>
                        <input type="text" class="form-control input-sm" id="cta" name="cta" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Cuanta No2.</label>
						<input type="text" class="form-control input-sm" id="ctaa" name="ctaa" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">

                        <label>Observaciones</label>
						<textarea  id="ob" name="ob" class="form-control input-sm"></textarea>
                        
							
						</form>
					</div>
					<div class="modal-footer">
						<button id="btnAgregarPersonaU" type="button" class="btn btn-primary" data-dismiss="modal">Actualizar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
    </html>
    
    <script type="text/javascript">
		$(document).ready(function(){

			$('#tablaPersonaLoad').load("proveedor/tablaProveedor.php");

			$('#btnAgregarPersona').click(function(){

				vacios=validarFormVacio('frmPersona');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmPersona').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/proveedor/agregaProveedor.php",
					success:function(r){
						if(r==2){
							$('#tablaPersonaLoad').load("proveedor/tablaProveedor.php");
								alertify.alert("Este Proveedor ya ha sido registrado, prueba con otro!!");
							}
						
						else if(r==1){
					//esta linea nos permite limpiar el formulario al insetar un registro
					$('#frmPersona')[0].reset();

					$('#tablaPersonaLoad').load("proveedor/tablaProveedor.php");
					alertify.success("Proveedor agregado con exito!!");
				}else{
					alertify.error("No se pudo agregar");
				}
			}
		});
			});
		});
	</script>

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnAgregarPersonaU').click(function(){

				datos=$('#frmPersonaU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/proveedor/actualizaProveedor.php",
					success:function(r){
						if(r==1){
							$('#tablaPersonaLoad').load("proveedor/tablaProveedor.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
			function agregaDato(id){

                $.ajax({
                            type:"POST",
                            data:"id=" + id,
                            url:"../denm_procesos/proveedor/obtenDatosProveedor.php",
                        success:function(r){
                        dato=jQuery.parseJSON(r);

                        $('#id').val(dato['prov_id']);
                        $('#cedula').val(dato['prov_ced']);
                        $('#ruc').val(dato['prov_ruc']);
                        $('#razon').val(dato['prov_razon_social']);
                        $('#direccion').val(dato['prov_direccion']);
                        $('#telefono').val(dato['prov_telefono']);
                        $('#correo').val(dato['prov_email']);
                        $('#cta').val(dato['prov_cta1']);
                        $('#ctaa').val(dato['prov_cta2']);
                        $('#ob').val(dato['prov_observacion']);
                      

 
}
});
}

		function eliminarProv(idper){
			alertify.confirm('¿Desea eliminar este Proveedor?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + idper,
					url:"../denm_procesos/proveedor/eliminaProveedor.php",
					success:function(r){
						if(r==1){
                            $('#tablaPersonaLoad').load("proveedor/tablaProveedor.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
	
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
<?php 
}else{
	header("location:../index.php");
}
?>