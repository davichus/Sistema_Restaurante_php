<?php
if (!isset($_POST["codigo"])) {
    return;
}

$codigo = $_POST["codigo"];
$cantidad = $_POST["cantidad"];

include_once "base_de_datos.php";
$sentencia = $base_de_datos->prepare("SELECT * FROM tbl_insumos WHERE ins_id = ? LIMIT 1;");
$sentencia->execute([$codigo]);
$producto = $sentencia->fetch(PDO::FETCH_OBJ);
# Si no existe, salimos y lo indicamos
if (!$producto) {
    header("Location: ./comprar.php?status=4");
    exit;
}
# Si no hay existencia...
if ($producto->ins_stock < 1) {
    header("Location: ./comprar.php?status=5");
    exit;
}
session_start();
# Buscar producto dentro del cartito
$indice = false;
for ($i = 0; $i < count($_SESSION["carrito"]); $i++) {
    if ($_SESSION["carrito"][$i]->ins_id === $codigo) {
        $indice = $i;
        break;
    }
}
# Si no existe, lo agregamos como nuevo
if ($indice === false) {
    $producto->ins_stock = 1;
    $producto->total = $producto->ins_precio;
    array_push($_SESSION["carrito"], $producto);
} else {
    # Si ya existe, se agrega la cantidad
    # Pero espera, tal vez ya no haya
    $cantidadExistente = $_SESSION["carrito"][$indice]->ins_stock;
    # si al sumarle uno supera lo que existe, no se agrega
    if ($cantidadExistente + 1 > $producto->ins_stock) {
        header("Location: ./comprar.php?status=5");
        exit;
    }
    $_SESSION["carrito"][$indice]->ins_stock++;
    $_SESSION["carrito"][$indice]->total = $_SESSION["carrito"][$indice]->ins_stock * $_SESSION["carrito"][$indice]->precioVenta;
}
header("Location: ./comprar.php");
