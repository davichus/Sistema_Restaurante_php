<?php require_once "../denm_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
		?>


<?php 
session_start();
if(isset($_SESSION['usuario'])){
	?>
<?php 

include_once "menu.php";
if(!isset($_SESSION["carrito"])) $_SESSION["carrito"] = [];
$granTotal = 0;
?>
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <h1>Crear Pedido</h1>
     
		<?php
			if(isset($_GET["status"])){
				if($_GET["status"] === "1"){
					?>
						<div class="alert alert-success">
							<strong>¡Correcto!</strong> Pedido realizado correctamente
						</div>
					<?php
				}else if($_GET["status"] === "2"){
					?>
					<div class="alert alert-info">
							<strong>Pedido cancelado</strong>
						</div>
					<?php
				}else if($_GET["status"] === "3"){
					?>
					<div class="alert alert-info">
							<strong>Ok</strong> Producto quitado de la lista
						</div>
					<?php
				}else if($_GET["status"] === "4"){
					?>
					<div class="alert alert-warning">
							<strong>Error:</strong> El Producto que buscas no existe
						</div>
					<?php
				}else if($_GET["status"] === "5"){
					?>
					<div class="alert alert-danger">
							<strong>Error: </strong>El producto está agotado
						</div>
					<?php
				}else{
					?>
					<div class="alert alert-danger">
							<strong>Error:</strong> Algo salió mal mientras se realizaba el pedido
						</div>
					<?php
				}
			}
		?>
        <br>
        <form action="ProductosHechos.php">
            <button type="submit" class="btn btn-warning btn-sm"> Pedidos Pendientes</button>
        </form>
       




		<form method="post" action="agregarAlCarrito1.php">
      
            <label>Insumo</label>
			<select class="form-control input-sm" id="codigo" name="codigo">
				<option value="0">Selecciona</option>
				<?php
				$sql="SELECT ins_id,ins_desc,catin_desc
                from tbl_insumos i
                inner join tbl_categoria_insumo  c on i.catin_id=c.catin_id";
				$result=mysqli_query($conexion,$sql);
				while ($cliente=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $cliente[0] ?>"><?php echo $cliente[1]." - ".$cliente[2] ?></option>
				<?php endwhile; ?>
            </select>
            
            <br>
		<button type="submit" class="btn btn-primary btn-sm">Agregar</button>
		</form>

        

		<br><br>
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>ID</th>
					<th>Insumo</th>
					<th>Tipo Unidad</th>
					<th>Precio de venta</th>
                 
					<th>Quitar</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($_SESSION["carrito"] as $indice => $producto){ 
						$granTotal += $producto->ins_precio;
					?>
				<tr>
					<td><?php echo $producto->ins_id ?></td>
					<td><?php echo $producto->ins_desc ?></td>
					<td><?php echo $producto->ins_unidad_tipo ?></td>
					<td><?php echo $producto->ins_precio ?></td>
                   
					<td><a class="btn btn-danger" href="<?php echo "quitarDelCarrito1.php?indice=" . $indice?>"><i class="fa fa-trash"></i></a></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>

		<h3>Total: <?php echo $granTotal; ?></h3>
        <br>
        
        <form action="" action="ventas1.php" method="POST">
        <label>Cedula Cliente</label>
        <input type="text" class="form-control input-sm" name="cedula" id="cedula">
        <br>
        <input type="submit" class="btn btn-primary" value="Buscar" name="buscar" >

        </form>
        
        
        <form action="./terminarVenta1.php" method="POST">
        
        
        
        <label for="codigo">Categoria:</label>
        <select class="form-control input-sm" id="cate" name="cate" >
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT catprod_id,catprod_desc
				from tbl_categoria_producto";
				$result=mysqli_query($conexion,$sql);
				while ($cliente=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $cliente[0] ?>"><?php echo $cliente[1] ?></option>
				<?php endwhile; ?>
            </select>
            <label for="codigo">Destino:</label>
        <select class="form-control input-sm" id="destino" name="destino" >
				<option value="A">Selecciona</option>
                <option value="Cocina">Cocina</option>
                <option value="Bar">Bar</option>
            </select>
            <label>Stock</label>
		<input type="number" class="form-control input-sm" id="stock" name="stock"   style="width : 60px; heigth : 1px" >
        <label>Precio</label>
		<input type="text" class="form-control input-sm" id="precio" name="precio"   style="width : 60px; heigth : 1px" >   
        <label for="codigo">Sucursal:</label>
        <select class="form-control input-sm" id="sl_sucursal" name="sl_sucursal" >
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT suc_id,suc_nombre
				from tbl_sucursal";
				$result=mysqli_query($conexion,$sql);
				while ($cliente=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $cliente[0] ?>"><?php echo $cliente[1] ?></option>
				<?php endwhile; ?>
            </select>

         <br>
     
			<input name="total" type="hidden" value="<?php echo $granTotal;?>">
			<button type="submit" class="btn btn-success">Crear Producto</button>
            <a href="./cancelarVenta1.php" class="btn btn-danger">Cancelar </a>
            <br>
            <br>
		</form>
        
	</div>
    <?php 
}else{
	header("location:../index.php");
}
?>