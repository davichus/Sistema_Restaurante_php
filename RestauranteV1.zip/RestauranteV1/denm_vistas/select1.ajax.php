<?php
include 'db1.php';
$id = $_POST["id"];

$estadosdb = ModeloPaises1::mdlTraerDependencias($id);

foreach ($estadosdb as $key => $value) {
	echo '<option value="'.$value["pro_id"].'">'.$value["pro_desc"].'</option>';
}