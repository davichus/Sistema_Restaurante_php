<?php
include 'db1.php';
$id = $_POST["id"];

$estadosdb = ModeloCategoria::mdlTraerDependenciass($id);

foreach ($estadosdb as $key => $value) {
	echo '<option value="'.$value["ins_id"].'">'.$value["ins_desc"].'</option>';
}