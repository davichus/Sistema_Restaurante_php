<?php 

require_once "../../denm_clases/Conexion.php";
$c= new conectar();
$conexion=$c->conexion();
?>
<?php  include 'db1.php';?>


<h4><b>Vender un producto </b></h4>

<div class="row">
	<div class="col-sm-4">
		<form id="frmVentasProductos" name="frmVentasProductos">
			

		
		<label>Seleciona Proveedor</label>
			<select class="form-control input-sm" id="clienteVenta" name="clienteVenta">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT prov_id,prov_ruc,prov_razon_social 
				from tbl_proveedor";
				$result=mysqli_query($conexion,$sql);
				while ($cliente=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $cliente[0] ?>"><?php echo $cliente[1]." ".$cliente[2] ?></option>
				<?php endwhile; ?>
            </select>
      
            <label>Insumo</label>
			<select class="form-control input-sm" id="sl_insumo" name="sl_insumo">
				<option value="0">Selecciona</option>
				<?php
				$sql="SELECT ins_id,ins_desc,catin_desc
                from tbl_insumos i
                inner join tbl_categoria_insumo  c on i.catin_id=c.catin_id";
				$result=mysqli_query($conexion,$sql);
				while ($cliente=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $cliente[0] ?>"><?php echo $cliente[1]." - ".$cliente[2] ?></option>
				<?php endwhile; ?>
            </select>
                 
                  <label>Tipo Unidad</label>
                  <input readonly="" type="text" class="form-control input-sm" id="unidadV" name="unidadV">
			<label>Stock</label>
			<input readonly="" type="text" class="form-control input-sm" id="stockV" name="stockV">
			<label>Precio</label>
			<input readonly="" type="text" class="form-control input-sm" id="precioV" name="precioV">
			
			<p></p>
			<span class="btn btn-primary" id="btnAgregaVenta">Agregar</span>
			<span class="btn btn-danger" id="btnVaciarVentas">Vaciar Compra</span>
		</form>
	</div>
	
	<div class="col-sm-4">
		<div id="tablaVentasTempLoad"></div>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){

		$('#tablaVentasTempLoad').load("compras/tablaCompraTemp.php");

		$('#sl_insumo').change(function(){
			$.ajax({
				type:"POST",
				data:"idins=" + $('#sl_insumo').val(),
				url:"../denm_procesos/compras/llenarFormInsumo.php",
				success:function(r){
					dato=jQuery.parseJSON(r);

                    $('#unidadV').val(dato['ins_unidad_tipo']);
                    $('#stockV').val(dato['ins_stock']);
                    $('#precioV').val(dato['ins_precio']);
				}
			});
		});

		$('#btnAgregaVenta').click(function(){
			vacios=validarFormVacio('frmVentasProductos');

			if(vacios > 0){
				alertify.alert("Debes llenar todos los campos!!");
				return false;
			}

			datos=$('#frmVentasProductos').serialize();
			$.ajax({
				type:"POST",
				data:datos,
				url:"../denm_procesos/compras/agregaInsumoTemp.php",
				success:function(r){
					$('#tablaVentasTempLoad').load("compras/tablaCompraTemp.php");
				}
			});
		});

		$('#btnVaciarVentas').click(function(){

		$.ajax({
			url:"../denm_procesos/compras/vaciarTemp.php",
			success:function(r){
				$('#tablaVentasTempLoad').load("compras/tablaCompraTemp.php");
			}
		});
	});

	});
</script>

<script type="text/javascript">
	function quitarP(index){
		$.ajax({
			type:"POST",
			data:"ind=" + index,
			url:"../denm_procesos/compras/quitarInsumo.php",
			success:function(r){
				$('#tablaVentasTempLoad').load("compras/tablaCompraTemp.php");
				alertify.success("Se quito el Insumo");
			}
		});
	}

	function crearVenta(){
		$.ajax({
			url:"../denm_procesos/compras/crearCompra.php",
			success:function(r){
				if(r > 0){
					$('#tablaVentasTempLoad').load("compras/tablaCompraTemp.php");
				   $('#frmVentasProductos')[0].reset();
					alertify.alert("Compra creada con exito, consulte la informacion de esta en compras hechas");
				}else if(r==0){
					alertify.alert("No hay lista de compra!!");
				}else{
					alertify.error("No se pudo crear la compra");
				}
			}
		});
	}
</script>

<script type="text/javascript">
	$(document).ready(function(){
		$('#clienteVenta').select2();
		$('#sl_insumo').select2();

	});
</script>