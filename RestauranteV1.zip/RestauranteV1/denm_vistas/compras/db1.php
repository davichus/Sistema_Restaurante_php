<?php

class Conexion{
	static public function conectar()
	{
		$link = new PDO("mysql:host=localhost;dbname=restaurante",
						"root",
						"");
		$link->exec("set names utf8");

		return $link;
	}
}

/**
 * 

 */
class ModeloCategoria
{
	
	static public function mdlShowCategoria(){

		$stmt = Conexion::conectar()->prepare("SELECT * FROM tbl_categoria_insumo");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

		$stmt = null;
	}

	static public function mdlTraerDependenciass($id_pais){

		$stmt = Conexion::conectar()->prepare("SELECT *from tbl_insumos
		WHERE catin_id = $id_pais");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

		$stmt = null;
	}
}



?>