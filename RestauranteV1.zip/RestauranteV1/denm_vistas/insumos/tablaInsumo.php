<?php 
			require_once "../../denm_clases/conexion.php";
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="SELECT i.ins_id,
            i.ins_desc,
            i.ins_unidad_tipo,
            c.catin_desc,
            i.ins_medidad,
            i.ins_cantidad_medidad,
            i.ins_stock,
            i.ins_stock_medida,
            i.ins_precio,
            i.ins_estado
     FROM tbl_insumos i
     inner join tbl_categoria_insumo c on i.catin_id=c.catin_id
     WHERE i.ins_estado='A'";
			$result=mysqli_query($conexion,$sql);
	 ?>


<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><label>Insumos</label></caption>
	<tr>
		<td>Insumo</td>
        <td>Tipo de Unidad</td>
        <td>Categoria</td>
        <td>Medida</td>
        <td>Stock</td>
        <td>Cant.Medida</td>
        <td>Precio</td>
        <td>Estado</td>
		<td colspan="2">Aciones</td>
		
	</tr>

	<?php
	while ($ver=mysqli_fetch_row($result)):
	 ?>

	<tr>
		<td><?php echo $ver[1] ?></td>
        <td><?php echo $ver[2] ?></td>
        <td><?php echo $ver[3] ?></td>
        <td><?php echo $ver[5] ?> <?php echo $ver[4] ?></td>
		<?php
		if($ver[6]=='0'){
			echo '<td class="btn btn-danger btn-xs">'.$ver[6].'</td>';
		}
		else{
			echo '<td class="btn btn-success btn-xs">'.$ver[6].'</td>';
		  }
		  
		
		?>
        <td><?php echo $ver[7] ?></td>
        <td><?php echo $ver[8] ?></td>
        <td><?php echo $ver[9] ?></td>
		<td>
			<span class="btn btn-warning btn-xs" data-toggle="modal" data-target="#abremodalPersonaUpdate" onclick="agregaDato('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
		<td>
			<span class="btn btn-danger btn-xs" onclick="eliminarProv('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-remove"></span>
			</span>
		</td>
	</tr>

<?php endwhile; ?>
</table>