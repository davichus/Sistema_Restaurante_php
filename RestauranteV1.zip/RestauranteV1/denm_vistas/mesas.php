<?php 
session_start();
if(isset($_SESSION['usuario']) and $_SESSION['rol']=='1'){
	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Citas Medicas</title>
        <?php require_once "menu.php"; ?>
        <?php require_once "../denm_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
		?>
    </head>



	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		
			<h1>Registro de Mesa</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmEsp">
                    <label>Sucursal</label>
			<select class="form-control input-sm" id="sl_suc" name="sl_suc">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT suc_id,
				suc_nombre
				from tbl_sucursal";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
			</select>
						<label>Mesa</label>
						<input type="text" class="form-control input-sm" name="txt_mesa" id="txt_mesa">
                        <label>No Sillas</label>
						<input type="number" class="form-control input-sm" name="txt_sillas" id="txt_sillas">
						<p></p>
						<center><span class="btn btn-primary" id="btnAgregaEsp" name="btnAgregaEsp">Registrar</span></center>

					</form>
				</div>
				<div class="col-sm-7">
					<div id="tablaEspecialidadLoad"></div>
				</div>
			</div>
		</div>


		<!-- Button trigger modal -->


		<!-- Modal -->
        <div class="modal fade" id="actualizaCaja" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Modificar Mesa</h4>
					</div>
					<div class="modal-body">
						<form id="frmEspU">
                            <input type="text" hidden="" id="id" name="id">
                            

                            <label>Sucursal</label>
			<select class="form-control input-sm" id="suc" name="suc">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT suc_id,
				suc_nombre
				from tbl_sucursal";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
			</select>
							<label>Mesa</label>
                            <input type="text" id="mesa" name="mesa" class="form-control input-sm">
                            <label>No Sillas</label>
						<input type="number" class="form-control input-sm" name="sillas" id="sillas">
                            
			
				</select>
						</form>
    

					</div>
					<div class="modal-footer">
						<button type="button" id="btnActualizaEsp" class="btn btn-warning" data-dismiss="modal">Aceptar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
	</html>
    <script type="text/javascript">
		$(document).ready(function(){

			$('#tablaEspecialidadLoad').load("mesas/tablaMesa.php");

			$('#btnAgregaEsp').click(function(){

				vacios=validarFormVacio('frmEsp');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmEsp').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/mesa/agregaMesa.php",
					success:function(r){
						if(r==2){
							$('#tablaEspecialidadLoad').load("mesas/tablaMesa.php");
								alertify.alert("Esta mesa ya ha sido registrada, prueba con otra!!");
							}
						
						else if(r==1){
					//esta linea nos permite limpiar el formulario al insetar un registro
					$('#frmEsp')[0].reset();

					$('#tablaEspecialidadLoad').load("mesas/tablaMesa.php");
					alertify.success("Mesa agregada con exito!!");
				}else{
					alertify.error("No se pudo agregar Mesa");
				}
			}
		});
			});
		});
	</script>

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnActualizaEsp').click(function(){

				datos=$('#frmEspU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/mesa/actualizaMesa.php",
					success:function(r){
						if(r==1){
							$('#tablaEspecialidadLoad').load("mesas/tablaMesa.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
		function agregaDato(id){

       $.ajax({
          type:"POST",
          data:"id=" + id,
         url:"../denm_procesos/mesa/obtenDatosMesa.php",
          success:function(r){
        dato=jQuery.parseJSON(r);

        $('#id').val(dato['mes_id']);
        $('#suc').val(dato['suc_id']);
        $('#mesa').val(dato['mes_desc']);
        $('#sillas').val(dato['mes_sillas']);
      
     
        
    }
});
}


		function eliminaEsp(ide){
			alertify.confirm('¿Desea cerrar esta Caja?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + ide,
					url:"../denm_procesos/mesa/eliminaMesa.php",
					success:function(r){
						if(r==1){
                            $('#tablaEspecialidadLoad').load("mesas/tablaMesa.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo Eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
	
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 

<?php 
}else{
	header("location:../index.php");
}
?>