<?php require_once "../denm_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
		?>


<?php 
session_start();
if(isset($_SESSION['usuario'])){
	$usu=$_SESSION['usuario'];
	?>
<?php 

include_once "menu.php";
if(!isset($_SESSION["carrito"])) $_SESSION["carrito"] = [];
$granTotal = 0;
?>


<?php include 'db.php'; 
          include 'db1.php';?>
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <h1>Crear Pedido</h1>
     
		<?php
			if(isset($_GET["status"])){
				if($_GET["status"] === "1"){
					?>
						<div class="alert alert-success">
							<strong>¡Correcto!</strong> Pedido realizado correctamente
						</div>
					<?php
				}else if($_GET["status"] === "2"){
					?>
					<div class="alert alert-info">
							<strong>Pedido cancelado</strong>
						</div>
					<?php
				}else if($_GET["status"] === "3"){
					?>
					<div class="alert alert-info">
							<strong>Ok</strong> Producto quitado de la lista
						</div>
					<?php
				}else if($_GET["status"] === "4"){
					?>
					<div class="alert alert-warning">
							<strong>Error:</strong> El Producto que buscas no existe
						</div>
					<?php
				}else if($_GET["status"] === "5"){
					?>
					<div class="alert alert-danger">
							<strong>Error: </strong>El producto está agotado
						</div>
					<?php
				}else{
					?>
					<div class="alert alert-danger">
							<strong>Error:</strong> Algo salió mal mientras se realizaba el pedido
						</div>
					<?php
				}
			}
		?>
		<br>
		<?php
		if($_SESSION['rol']=="1" or $_SESSION['rol']=="3"):
         ?>
        <form action="consultaVentas.php">
            <button type="submit" class="btn btn-success btn-sm">Consultar Historial de Ventas</button>
		</form>
		<br>



		
        <form action="VentasHechas.php">
            <button type="submit" class="btn btn-danger btn-sm"> Pedidos Pendientes</button>
		</form>
		<br>
		<form action="VentasFacturadas.php">
            <button type="submit" class="btn btn-primary btn-sm"> Ventas Facturadas</button>
		</form>
		
		<?php 
       endif;
          ?>
		<br>
		<br>
		<form action="VentasHechas1.php">
            <button type="submit" class="btn btn-warning btn-sm"> Ver mi pedido</button>
        </form>
       
        <?php
		if($_SESSION['rol']=="1" or $_SESSION['rol']=="2"):
         ?>

		<form method="post" action="agregarAlCarrito2.php">
      
		<label>Categoria Producto</label>
                        <select class="form-control input-sm" id="selectpaisesid"  name="selectpaisesid" onchange="selectpaises1()">
          			<option value="">--Seleccione Categoria--</option>
                <?php
                    $paisesdb = ModeloPaises1::mdlShowPaises();
                    foreach ($paisesdb as $key => $value) {
                      echo '<option value="'. $value["catprod_id"] .'"> '. $value["catprod_desc"] .'</option>';
                    }
                ?>
          			
          		</select>
			
            <label>Productos</label>
			<select class="form-control input-sm" id="selectestado" name="selectestado">
          			<option value="">--Seleccione Producto--</option>
          		</select>
		   
            
            <br>
		<button type="submit" class="btn btn-primary btn-sm">Agregar</button>
		</form>

        

		<br><br>
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>ID</th>
					<th>Producto</th>
					
					<th>Precio de venta</th>
                 
					<th>Quitar</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($_SESSION["carrito"] as $indice => $producto){ 
						$granTotal += $producto->pro_precio;
					?>
				<tr>
					<td><?php echo $producto->pro_id ?></td>
					<td><?php echo $producto->pro_desc ?></td>
				
					<td><?php echo $producto->pro_precio ?></td>
                   
					<td><a class="btn btn-danger" href="<?php echo "quitarDelCarrito2.php?indice=" . $indice?>"><i class="fa fa-trash"></i></a></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>

		<h3>Subotal: <?php echo $granTotal; ?></h3>
		<h3>Iva 12%: <?php echo $granTotal*0.12; ?></h3>
		<h3>Total: <?php echo ($granTotal*0.12)+$granTotal; ?></h3>
        <br>
        
        <form action="./terminarVenta2.php" method="POST">

		<label>Codigo de Venta</label>
		<?php
				$sql="SELECT max(ven_codigo)+1 from venta";
				$result=mysqli_query($conexion,$sql);
				while ($cliente=mysqli_fetch_row($result)):
					?>
					<input readonly type="text" class="form-control input-sm" name="venta" id="venta" value="00000<?php echo $cliente[0] ?>">
				<?php endwhile; ?>
         


		

        <label for="codigo">Cliente:</label>
        <select class="form-control input-sm" id="cliente" name="cliente" readonly="">
				
				<?php
				$sql="SELECT p.per_id,p.per_ced,p.per_apepat,p.per_apemat,p.per_nom
				from tbl_persona p
				inner join tbl_usuario u on p.per_id=u.per_id
				where u.usu_nomlogin='$usu'";
				$result=mysqli_query($conexion,$sql);
				while ($cliente=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $cliente[0] ?>"><?php echo $cliente[1] ?>-<?php echo $cliente[2] ?> <?php echo $cliente[3] ?> <?php echo $cliente[4] ?></option>
				<?php endwhile; ?>
            </select>
        
        
        <label for="codigo">Sucursal:</label>
        <select class="form-control input-sm" id="sucursal" name="sucursal" >
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT suc_id,suc_nombre
				from tbl_sucursal";
				$result=mysqli_query($conexion,$sql);
				while ($cliente=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $cliente[0] ?>"><?php echo $cliente[1] ?></option>
				<?php endwhile; ?>
            </select>
            <label for="codigo">Caja:</label>
        <select class="form-control input-sm" id="caja" name="caja" readonly="">
				
				<?php
				$sql="SELECT caj_id,caj_desc
				from tbl_caja where caj_desc='Pendiente'";
				$result=mysqli_query($conexion,$sql);
				while ($cliente=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $cliente[0] ?>"><?php echo $cliente[1] ?></option>
				<?php endwhile; ?>
            </select>
            <label for="codigo">Mesa:</label>
        <select class="form-control input-sm" id="mesa" name="mesa">
        <option value="A">Selecciona</option>
				<?php
				$sql="SELECT mes_id,mes_desc
				from tbl_mesa";
				$result=mysqli_query($conexion,$sql);
				while ($cliente=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $cliente[0] ?>"><?php echo $cliente[1] ?></option>
				<?php endwhile; ?>
            </select>
           

         <br>
     
			<input name="total" type="hidden" value="<?php echo $granTotal;?>">
			<button type="submit" class="btn btn-success">Crear Pedido</button>
            <a href="./cancelarVenta2.php" class="btn btn-danger">Cancelar </a>
            <br>
            <br>
		</form>
        <?php 
       endif;
          ?>
	</div>

	<script src="js1.js"></script>
    <?php 
}else{
	header("location:../index.php");
}
?>