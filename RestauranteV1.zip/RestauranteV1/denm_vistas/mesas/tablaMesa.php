<?php 
			require_once "../../denm_clases/conexion.php";
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="SELECT m.mes_id,
                         s.suc_nombre,
                         m.mes_desc,
                         m.mes_sillas,
                         m.mes_estado
                    FROM tbl_mesa m
                    inner join tbl_sucursal s on m.suc_id=s.suc_id
                    where m.mes_estado='A'";
			$result=mysqli_query($conexion,$sql);
	 ?>


<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><label>Mesas</label></caption>
	<tr>
        <td>Sucursal</td>
        <td>Mesa No</td>
        <td>No de Sillas</td>
		<td>Estado</td>
		<td colspan="2">Aciones</td>
		
	</tr>

	<?php
	while ($ver=mysqli_fetch_row($result)):
	 ?>

	<tr>
		<td><?php echo $ver[1] ?></td>
        <td><?php echo $ver[2] ?></td>
        <td><?php echo $ver[3] ?></td>
        <td><?php echo $ver[4] ?></td>
		<td>
		<span  data-toggle="modal" data-target="#actualizaCaja" class="btn btn-warning btn-xs" onclick="agregaDato('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
		<td>
			<span class="btn btn-danger btn-xs" onclick="eliminaEsp('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-remove"></span>
			</span>
		</td>
	</tr>

<?php endwhile; ?>
</table>