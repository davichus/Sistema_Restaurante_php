<?php 
session_start();
if(isset($_SESSION['usuario']) and $_SESSION['rol']=='1' or $_SESSION['rol']=="3"){
	?>

<?php
include_once "menu.php";
include_once "base_de_datos.php";
$sentencia = $base_de_datos->query("SELECT compras.total, compras.fecha,compras.codigo ,compras.id_com, concat_ws(' ', tbl_persona.per_ced,tbl_persona.per_apepat,tbl_persona.per_apemat,tbl_persona.per_nom) as persona, round(((compras.total*0.12)+compras.total),2) as totales ,GROUP_CONCAT( tbl_insumos.ins_id, '..', tbl_insumos.ins_desc, '..',tbl_insumos.ins_precio, '..', compras_vendidos.cantidad SEPARATOR '__') AS productos FROM compras INNER JOIN compras_vendidos ON compras_vendidos.id_com = compras.id_com INNER JOIN tbl_insumos ON tbl_insumos.ins_id = compras_vendidos.ins_id inner join tbl_usuario on tbl_usuario.usu_id=compras.usu_id inner join tbl_persona on tbl_persona.per_id=tbl_usuario.per_id GROUP BY compras.id_com ORDER BY compras.id_com");
$ventas = $sentencia->fetchAll(PDO::FETCH_OBJ);
?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<h1>Compras Hechas</h1>
		<div>
			<a class="btn btn-success" href="./comprar.php">Nueva <i class="fa fa-plus"></i></a>
		</div>
		<br>
		<table class="table table-bordered">
			<thead>
				<tr>
                    <th>Realizado Por</th>
                    <th>Codigo</th>
					<th>Fecha</th>
					<th>Insumos Comprados</th>
					<th>Totales</th>
					<th>Eliminar</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($ventas as $venta){ ?>
				<tr>
                    <td><?php echo $venta->persona ?></td>
                    <td><?php echo $venta->codigo ?></td>
					<td><?php echo $venta->fecha ?></td>
					<td>
						<table class="table table-bordered">
							<thead>
								<tr>
									
									<th>Insumo</th>
                                    <th>Cantidad</th>
                                    <th>Precio</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach(explode("__", $venta->productos) as $productosConcatenados){ 
								$producto = explode("..", $productosConcatenados)
								?>
								<tr>
	
									<td><?php echo $producto[1] ?></td>
                                    <td><?php echo $producto[3] ?></td>
                                    <td><?php echo $producto[2] ?></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
					</td>
                    <td><b>Subtotal:</b> <?php echo $venta->total ?> <br>
                   <b>Iva 12%:</b> <?php echo $venta->total*0.12 ?><br>
                <b> Total:</b> <?php echo ($venta->totales)?></td>
					<td><a class="btn btn-danger" href="<?php echo "eliminarVenta.php?id=" . $venta->id?>"><i class="fa fa-trash"></i></a></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
    <?php 
}else{
	header("location:../index.php");
}
?>