<?php 
session_start();
if(isset($_SESSION['usuario'])){

	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Ventas</title>
		<?php require_once "menu.php"; ?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Historial de Ventas</h1>
			<div class="row">
				<div class="col-sm-4">
					<form  method="POST" action="../denm_vistas/historialVentas.php">
					    <label>Ingrese Fechas</label>
                        <input type="date" class="form-control input-sm" id="codigo" name="fecha1" placeholder="" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>A</label>
                        <input type="date" class="form-control input-sm" id="codigo" name="fecha2" placeholder="" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <p></p>
                        <input type="submit" class="btn btn-primary" value="Buscar" name="buscar">
						
					</form>
				</div>
				
			</div>
		</div>

		<!-- Button trigger modal -->


		<!-- Modal -->
		
       
	</body>
    </html>
	
    <script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
<?php 
}else{
	header("location:../index.php");
}
?>