<?php 
session_start();
if(isset($_SESSION['usuario']) and $_SESSION['rol']=='1'){
	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Sistema Restaurante/Bar</title>
		<?php require_once "menu.php"; ?>
    </head>



	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Categorias de Productos</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmRol">
						<label>Categoria </label>
						<input type="text" class="form-control input-sm" name="txt_catpro" id="txt_catpro" >
                       
						<p></p>
						<center><span class="btn btn-primary" id="btnAgregaRol" name="btnAgregaRol">Registrar</span></center>

					</form>
				</div>
				<div class="col-sm-7">
					<div id="tablaRolLoad"></div>
				</div>
			</div>
		</div>


		<!-- Button trigger modal -->


		<!-- Modal -->
        <div class="modal fade" id="actualizaRol" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Modificar Categoria</h4>
					</div>
					<div class="modal-body">
						<form id="frmRolU">
							<input type="text" hidden="" id="id" name="id" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
							<label>Rol</label>
							<input type="text" id="pro" name="pro" class="form-control input-sm">
						</form>


					</div>
					<div class="modal-footer">
						<button type="button" id="btnActualizaRol" class="btn btn-warning" data-dismiss="modal">Aceptar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
	</html>
    
					
<script type="text/javascript">
	$(document).ready(function(){
		$('#tablaRolLoad').load("catpro/tablaCatpro.php");

		$('#btnAgregaRol').click(function(){

			if($('#txt_catpro').val()==""){
				alertify.alert("Debes agregar la categoria");
				return false;
			}

			cadena="rol=" + $('#txt_catpro').val() ;

					$.ajax({
						type:"POST",
						url:"../denm_procesos/catpro/agregaCatpro.php",
						data:cadena,
						success:function(r){

							if(r==2){
                                $('#tablaRolLoad').load("catpro/tablaCatpro.php");
								alertify.alert("Esta categoria ya existe, prueba con otro!!");
							}
							else if(r==1){
								$('#frmRol')[0].reset();
                                $('#tablaRolLoad').load("catpro/tablaCatpro.php");
								alertify.success("Agregado con exito");
							}else{
								alertify.error("Fallo al agregar");
							}
						}
					});
		});
	});
</script>
	
	
	
	

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnActualizaRol').click(function(){

				datos=$('#frmRolU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/catpro/actualizaCatpro.php",
					success:function(r){
						if(r==1){
                            $('#tablaRolLoad').load("catpro/tablaCatpro.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
		function agregaDato(idrol,rol){
			$('#id').val(idrol);
			$('#pro').val(rol);
		}

		function eliminaRol(idrol){
			alertify.confirm('¿Desea eliminar este Rol?', function(){ 
				$.ajax({
					type:"POST",
					data:"idpro=" + idrol,
					url:"../denm_procesos/catpro/eliminaCatpro.php",
					success:function(r){
						if(r==1){
                            $('#tablaRolLoad').load("catpro/tablaCatpro.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
	
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 

<?php 
}else{
	header("location:../index.php");
}
?>
