<?php 
session_start();
if(isset($_SESSION['usuario']) and $_SESSION['rol']=='1'or $_SESSION['rol']=="3"){
	?>
<?php require_once "../denm_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
        ?>
<?php
include_once "menu.php";
include_once "base_de_datos.php";
if(!isset($_POST["fecha1"]) && !isset($_POST["fecha2"])) exit;
$fecha1=$_POST["fecha1"];
$fecha2=$_POST["fecha2"];



$sentencia = $base_de_datos->query("SELECT venta.ven_id,
venta.ven_codigo, tbl_sucursal.suc_nombre, 
tbl_usuario.usu_correo,
tbl_usuario.usu_nomlogin,
tbl_caja.caj_desc,
tbl_mesa.mes_desc,
venta.ven_efectivo,
venta.ven_visa,
venta.ven_mastercard,
venta.ven_precio,
venta.ven_fecha,
venta.pro_estado,
concat_ws(' ', tbl_persona.per_ced,tbl_persona.per_apepat,tbl_persona.per_apemat,tbl_persona.per_nom) as cliente, 
GROUP_CONCAT( productos.pro_id, '..', productos.pro_desc, '..',productos.pro_precio, '..', ventas_hechas.cantidad SEPARATOR '__') AS productos,
round(((venta.ven_precio*0.12)+venta.ven_precio),2) as totales 
FROM venta 
INNER JOIN ventas_hechas ON ventas_hechas.ven_id = venta.ven_id 
INNER JOIN productos ON productos.pro_id = ventas_hechas.pro_id 
inner join tbl_usuario on tbl_usuario.usu_id=venta.usu_id 
inner join tbl_persona on tbl_persona.per_id=venta.per_id
INNER join tbl_sucursal on tbl_sucursal.suc_id=venta.suc_id 
inner join tbl_caja on tbl_caja.caj_id=venta.caj_id
inner join tbl_mesa on tbl_mesa.mes_id=venta.mes_id
where venta.ven_fecha BETWEEN '$fecha1' and '$fecha2'
GROUP BY venta.ven_id ORDER BY venta.ven_id");
$ventas = $sentencia->fetchAll(PDO::FETCH_OBJ);
?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<h1>Pedidos</h1>
		<div>
			<a class="btn btn-success" href="./ventas.php">Nueva <i class="fa fa-plus"></i></a>
		</div>
		<br>
		<table class="table table-bordered">
			<thead>
				<tr>
                    <th>Codigo Venta</th>
                    <th>Fecha</th>
                    <th>Sucursal</th>
                    <th>Realizado por</th>
                    <th>Facturado Por</th>
                    <th>Mesa</th>
                    <th>Cliente</th>
                    <th>Pagos</th>
                    <th>Pedido</th>
                  
                    <th>Totales</th>
                    <th>Estado de Pago</th>
					<th colspan="2">Acciones</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($ventas as $venta){ ?>
				<tr>
                    <td><?php echo $venta->ven_codigo ?></td>
                    <td><?php echo $venta->ven_fecha ?></td>
                    <td><?php echo $venta->suc_nombre ?></td>
                    <td><b>Correo:</b><?php echo $venta->usu_correo ?><br>
                        <b>Usuario:</b><?php echo $venta->usu_nomlogin ?></td>
                    <td><?php echo $venta->caj_desc ?></td>
                    <td><?php echo $venta->mes_desc ?></td>
                    <td><?php echo $venta->cliente ?></td>
                    <td><b>Efectivo:</b><?php echo $venta->ven_efectivo ?><br>
                       <b>Visa:</b><?php echo $venta->ven_visa ?><br>
                       <b>Mastercard:</b><?php echo $venta->ven_mastercard ?></td>
					<td>
						<table class="table table-bordered">
							<thead>
								<tr>
									
									<th>Insumo</th>
                                    <th>Cantidad</th>
                                    <th>Precio</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach(explode("__", $venta->productos) as $productosConcatenados){ 
								$producto = explode("..", $productosConcatenados)
								?>
								<tr>
	
									<td><?php echo $producto[1] ?></td>
                                    <td><?php echo $producto[3] ?></td>
                                    <td><?php echo $producto[2] ?></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
                   
                    <td><b>Subtotal:</b> <?php echo $venta->ven_precio ?> <br>
                   <b>Iva 12%:</b> <?php echo $venta->ven_precio*0.12 ?><br>
                <b> Total:</b> <?php echo ($venta->totales)?>
                
                </td>
                <?php
		if( $venta->pro_estado=='Pendiente'){
			echo '<td class="btn btn-danger btn-xs">'.$venta->pro_estado.'</td>';
		}
		else{
			echo '<td class="btn btn-success btn-xs">'.$venta->pro_estado.'</td>';
		  }
		  
		
		?>
             <td>
		<span  data-toggle="modal" data-target="#actualizaVenta" class="btn btn-warning " onclick="agregaDato('<?php echo $venta->ven_id ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>


					<td><a class="btn btn-danger" href="<?php echo "eliminarVenta.php?id=" . $venta->id?>"><i class="fa fa-trash"></i></a></td>
				
				
					<td><a href="../denm_procesos/venta/crearReportePdf1.php?ven_id=<?php echo $venta->ven_id ?>" class="btn btn-danger btn-sm">
							Imprimir <span class="glyphicon glyphicon-file"></span>
						</a></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
    </div>
       <!-- Modal -->
		<div class="modal fade" id="actualizaVenta" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualizar Venta</h4>
					</div>
					<div class="modal-body">
						<form id="frmPersonaU" name="frmPersonaU">
                        <input type="text" hidden="" id="id" name="id">
                        
                        <label>Caja</label>
                          <select class="form-control input-sm" id="caja" name="caja">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT caj_id,
			     caj_desc
				from tbl_caja";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
			</select>
            <label>Pago Efectivo</label>
			<input type="text" class="form-control input-sm" id="efectivo" name="efectivo"  onKeyUp="Suma1()" style="width : 60px; heigth : 1px" onclick="Suma1()">
            <label>Visa</label>
			<input type="text" class="form-control input-sm" id="visa" name="visa"  onKeyUp="Suma1()" style="width : 60px; heigth : 1px" onclick="Suma1()">           
            <label>Mastercard</label>
			<input type="text" class="form-control input-sm" id="master" name="master"  onKeyUp="Suma1()" style="width : 60px; heigth : 1px" onclick="Suma1()">                      
            
            <label>SubTotal</label>
			<input type="text" readonly="" class="form-control input-sm" id="total" name="total"  onKeyUp="Suma1()" style="width : 60px; heigth : 1px" onclick="Suma1()">                      
            <label>Iva 12%</label>
            <input type="text" readonly="" class="form-control input-sm" id="iva" name="iva"  onKeyUp="Suma1()" style="width : 60px; heigth : 1px" onclick="Suma1()">  
            <label>Total</label>
			<input type="text" readonly="" class="form-control input-sm" id="totales" name="totales"  onKeyUp="Suma1()" style="width : 60px; heigth : 1px" onclick="Suma1()">  
            <label>Vuelto</label>
			<input type="text" readonly="" class="form-control input-sm" id="vuelto" name="vuelto"  onKeyUp="Suma1()" style="width : 60px; heigth : 1px" onclick="Suma1()">
        
                   <label>Estado Pago</label>
							<br>
							<select name="estado" class="form-control input-sm" id="estado" required>
                          <option value="" disabled selected hidden>--Seleccione--</option>
                          <option value="Pagado">Pagado</option>
                          <option value="Pendiente">Pendiente</option>
                     
                         
                       
                          </select>
                    
                      
							
						</form>
					</div>
					<div class="modal-footer">
						<button id="btnAgregarPersonaU" type="button" class="btn btn-primary" data-dismiss="modal">Actualizar</button>

					</div>
				</div>
			</div>
        </div>
        <script>
//Función que realiza la suma
     function Suma1() {
   var ingreso1 = document.frmPersonaU.efectivo.value;
   var ingreso2 = document.frmPersonaU.totales.value;
   var ingreso3 = document.frmPersonaU.visa.value;
   var ingreso4 = document.frmPersonaU.master.value;

   try{
      //Calculamos el número escrito:
       ingreso1 = (isNaN(parseFloat(ingreso1)))? 0 : parseFloat(ingreso1);
       ingreso2 = (isNaN(parseFloat(ingreso2)))? 0 : parseFloat(ingreso2);
       ingreso3 = (isNaN(parseFloat(ingreso3)))? 0 : parseFloat(ingreso3);
       ingreso4 = (isNaN(parseFloat(ingreso4)))? 0 : parseFloat(ingreso4);
       document.frmPersonaU.vuelto.value = ((ingreso1+ingreso3+ingreso4)-ingreso2).toFixed(2);
   }
   //Si se produce un error no hacemos nada
   catch(e) {}
   }
   
</script>

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnAgregarPersonaU').click(function(){

				datos=$('#frmPersonaU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/venta/actualizaVenta.php",
					success:function(r){
						if(r==1){
                            window.location="VentasHechas.php";
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>





        <script type="text/javascript">
			function agregaDato(id){

                $.ajax({
                            type:"POST",
                            data:"id=" + id,
                            url:"../denm_procesos/venta/obtenDatosVenta.php",
                        success:function(r){
                        dato=jQuery.parseJSON(r);

                        $('#id').val(dato['ven_id']);
                        $('#caja').val(dato['caj_id']);
                        $('#efectivo').val(dato['ven_efectivo']);
                        $('#visa').val(dato['ven_visa']);
                        $('#master').val(dato['ven_mastercard']);
                        $('#total').val(dato['ven_precio']);
                        $('#estado').val(dato['pro_estado']);
                        $('#iva').val(dato['iva']);
                        $('#totales').val(dato['total']);
                     
}
});
}

		function eliminarProv(idper){
			alertify.confirm('¿Desea eliminar este Insumo?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + idper,
					url:"../denm_procesos/insumos/eliminaInsumo.php",
					success:function(r){
						if(r==1){
                            $('#tablaPersonaLoad').load("insumos/tablaInsumo.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>






    <?php 
}else{
	header("location:../index.php");
}
?>