<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Lumino - Login</title>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<link href="../css/datepicker3.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
	<script src="../js/funciones.js"></script>
	

	<link rel="stylesheet" type="text/css" href="../librerias/alertifyjs/css/alertify.css">
    <link rel="stylesheet" type="text/css" href="../librerias/alertifyjs/css/themes/default.css">
    <link rel="stylesheet" type="text/css" href="../librerias/select2/css/select2.css">



<script src="../librerias/jquery-3.2.1.min.js"></script>
<script src="../librerias/alertifyjs/alertify.js"></script>
<script src="../librerias/bootstrap/js/bootstrap.js"></script>
<script src="../librerias/select2/js/select2.js"></script>


	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
			<div class="login-panel panel panel-default">
				<div class="panel-heading"><center>Recuperar Contraseña</center></div>
				<div class="panel-body">
             
						<fieldset>
                        <form id="frmRegistro" onsubmit="return validar()" >
							<div class="form-group">
								<input class="form-control" placeholder="Usuario" name="usu" id="usu" type="text" autofocus="">
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Ultima contraseña que recuerdes" name="pass1" id="pass1" type="password" value="">
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Contraseña" name="pass" id="pass" type="password" value="">
							</div>
						
                      
                            <!--<a href="index.html" class="btn btn-primary">Login</a>-->
                            
                            <center>
                            <!--<input type="submit" class="btn btn-primary btn-sm" id="entrarSistema" value="Ingresar" tyle="font-size: 1.25em">-->
                            
                        <span class="btn btn-primary btn-sm" id="registro" style="font-size: 1.25em">Actualizar</span>
							
							<a href="../index.php" class="btn btn-danger btn-sm" style="font-size: 1.25em">Regresar al Login</a>
							</center>
							<br>
							<a href="denm_vistas/recuperar.php" >Olvide mi contraseña</a>
                            
                            </fieldset>
					
				</div>
			</div>
		</div><!-- /.col-->
         <!-- Modal -->
		




	</div><!-- /.row -->	
	

<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#registro').click(function(){

				datos=$('#frmRegistro').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/reglogin/nuevacontra.php",
					success:function(r){
                        var pagina="../index.php"
						if(r==1){
                            location.href=pagina
							alertify.success("Contraseña Actualizada con exito");
						}else{
							alertify.error("No se pudo actualizar");
						}
					}
				});
			});
		});
	</script>




    



<script type="text/javascript">
    function validar() {
 //obteniendo el valor que se puso en el campo text del formulario
 var miCampoTexto = document.getElementById("txt_usu").value;
 //la condición
 if (miCampoTexto.length == 0 || /^\s+$/.test(miCampoTexto)) {
   // alert('Ingrese su Usuario!');
	alertify.alert("Ingresa tu Usuario Por Favor!!");
     return false;
 }
    
 //Validando el combo select
 var miCombo = document.getElementById("txt_pass").value;
 if(miCombo == ""){
    // alert('Ingrese su Contraseña');
	alertify.alert("Ingresa tu contraseña Por Favor!!");
     return false;
 }

 return true;
 }
</script>

<script src="../js/jquery-1.11.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/chart.min.js"></script>
	<script src="../js/chart-data.js"></script>
	<script src="../js/easypiechart.js"></script>
	<script src="../js/easypiechart-data.js"></script>
	<script src="../js/bootstrap-datepicker.js"></script>
	<script src="../js/custom.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>



</body>
</html>


