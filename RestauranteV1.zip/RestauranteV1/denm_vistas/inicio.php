<?php 
	session_start();
	if(isset($_SESSION['usuario'])){
		
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Inicio</title>
	<?php require_once "menu.php"; ?>
	<?php require_once "../denm_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
		?>
	
</head>
<body>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
<div class="panel panel-container">
			<div class="row">
				
			<?php
		if($_SESSION['rol']=="1" or $_SESSION['rol']=="3"):
         ?>
			     <div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-teal panel-widget border-right">
						<div class="row no-padding">
						<em class="fa fa-xl "><img src="imagenes/rebaja.png" class="img-responsive">
						</em>
						
							<?php
				$sql="SELECT count(*)As total,SUM(round((ven_precio*0.12)+ven_precio,2))as total FROM venta";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					
							<div class="large"><?php echo $producto[0] ?></div>

						

							<div class="text-muted">Ventas Realizadas</div>
						     
							<div class="large">$<?php echo $producto[1] ?></div>

							<div class="text-muted">Totales</div>
							<?php endwhile; ?>
							<a href="VentasHechas.php"> Ver Info</a>
						</div>
					</div>
				</div>
				<?php 
       endif;
          ?>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-blue panel-widget border-right">
						<div class="row no-padding"><em class="fa fa-xl fa">
						<img src="imagenes/comida-rapida.png" class="img-responsive">
						</em>
						<?php
				$sql="SELECT count(*)As total
				FROM productos";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					
							<div class="large"><?php echo $producto[0] ?></div>

							<?php endwhile; ?>

							<div class="text-muted">Productos</div>
							<a href="ProductosHechos.php"> Ver Info</a>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-orange panel-widget border-right">
						<div class="row no-padding"><em class="fa fa-xl fa">

						<img src="imagenes/camarero.png" class="img-responsive">
						</em>
						<?php
				$sql="SELECT count(*)As total
				FROM tbl_empleado";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					
							<div class="large"><?php echo $producto[0] ?></div>

							<?php endwhile; ?>

							<div class="text-muted">Empleados</div>
							<a href="empleados.php"> Ver Info</a>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-red panel-widget ">
						<div class="row no-padding"><em class="fa fa-xl fa">
						<img src="imagenes/cafe.png" class="img-responsive">

						</em>
						<?php
				$sql="SELECT count(*)As total
				FROM tbl_sucursal";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					
							<div class="large"><?php echo $producto[0] ?></div>

							<?php endwhile; ?>

							<div class="text-muted">Sucursales</div>
						
							<a href="sucursal.php"> Ver Info</a>
						
						
						</div>
					</div>
				</div>

            

			</div><!--/.row-->

			<?php
		if($_SESSION['rol']=="1" or $_SESSION['rol']=="3"):
         ?>
			<div class="row">
			<div class="col-md-6">
			<div class="panel panel-default">
					<div class="panel-heading">
						Monitor
						<ul class="pull-right panel-settings panel-button-tab-right">
							<li class="dropdown"><a class="pull-right dropdown-toggle" data-toggle="dropdown" href="#">
								<em class="fa fa-cogs"></em>
							</a>
								<ul class="dropdown-menu dropdown-menu-right">
									<li>
										<ul class="dropdown-settings">
											<li><a href="#">
												<em class="fa fa-cog"></em> Settings 1
											</a></li>
											<li class="divider"></li>
											<li><a href="#">
												<em class="fa fa-cog"></em> Settings 2
											</a></li>
											<li class="divider"></li>
											<li><a href="#">
												<em class="fa fa-cog"></em> Settings 3
											</a></li>
										</ul>
									</li>
								</ul>
							</li>
						</ul>
						<span class="pull-right clickable panel-toggle panel-button-tab-left"><em class="fa fa-toggle-up"></em></span></div>
					<div class="panel-body">
					
					<?php
include_once "menu.php";
include_once "base_de_datos.php";
$sentencia = $base_de_datos->query("SELECT venta.ven_id,
venta.ven_codigo, tbl_sucursal.suc_nombre, 
tbl_usuario.usu_correo,
tbl_usuario.usu_nomlogin,
tbl_caja.caj_desc,
tbl_mesa.mes_desc,
venta.ven_efectivo,
venta.ven_visa,
venta.ven_mastercard,
venta.ven_precio,
venta.ven_fecha,
venta.pro_estado,
concat_ws(' ', tbl_persona.per_ced,tbl_persona.per_apepat,tbl_persona.per_apemat,tbl_persona.per_nom) as cliente, 
GROUP_CONCAT( productos.pro_id, '..', productos.pro_desc, '..',productos.pro_precio, '..', ventas_hechas.cantidad SEPARATOR '__') AS productos,
round(((venta.ven_precio*0.12)+venta.ven_precio),2) as totales 
FROM venta 
INNER JOIN ventas_hechas ON ventas_hechas.ven_id = venta.ven_id 
INNER JOIN productos ON productos.pro_id = ventas_hechas.pro_id 
inner join tbl_usuario on tbl_usuario.usu_id=venta.usu_id 
inner join tbl_persona on tbl_persona.per_id=venta.per_id
INNER join tbl_sucursal on tbl_sucursal.suc_id=venta.suc_id 
inner join tbl_caja on tbl_caja.caj_id=venta.caj_id
inner join tbl_mesa on tbl_mesa.mes_id=venta.mes_id
where venta.ven_fecha=CURRENT_DATE() and venta.pro_estado='Pendiente'
GROUP BY venta.ven_id ORDER BY venta.ven_id");
$ventas = $sentencia->fetchAll(PDO::FETCH_OBJ);
?>
				<?php foreach($ventas as $venta){ ?>
             
					<ul class="todo-list">
							<li class="todo-list-item">
								<div class="checkbox">
								<br>
				<br>
									<b></b><label for="checkbox-1"><?php echo $venta->mes_desc ?></label>
					
						<table class="table table-bordered">
							<thead>
								<tr>
									
									<th>Insumo</th>
                                    <th>Cantidad</th>
                                    <th>Precio</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach(explode("__", $venta->productos) as $productosConcatenados){ 
								$producto = explode("..", $productosConcatenados)
								?>
								<tr>
	
									<td><?php echo $producto[1] ?></td>
                                    <td><?php echo $producto[3] ?></td>
                                    <td><?php echo $producto[2] ?></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
                   
                    <td><b>Subtotal:</b> <?php echo $venta->ven_precio ?> <br><br>
                   <b>Iva 12%:</b> <?php echo $venta->ven_precio*0.12 ?><br><br>
                <b> Total:</b> <?php echo ($venta->totales)?>
                
				</td>
				<br>
				<br>
                <?php
		if( $venta->pro_estado=='Pendiente'){
			echo '<button class="btn btn-danger btn-xs">'.$venta->pro_estado.'</button>';
		}
		else{
			echo '<td class="btn btn-success btn-xs">'.$venta->pro_estado.'</td>';
		  }
		  
		
		?>
				</tr>
				<?php } ?>
			</tbody>
		</table>
		</div>
								<div class="pull-right action-buttons"><a href="#" class="card-view">
									<em class="card-view"></em>
								</a></div>
							</li>
							
						</ul>
					
					</div>

					<div class="panel-footer">
						
					</div>
				</div>
				</div>
				</div>
				
				<?php 
       endif;
          ?>

<?php
		if($_SESSION['rol']=="1" or $_SESSION['rol']=="3"):
         ?>
<div class="row">

			<div class="col-md-6">
				<div class="panel panel-default chat">
					<div class="panel-heading">
						Total Ventas en cajas
						<ul class="pull-right panel-settings panel-button-tab-right">
							<li class="dropdown"><a class="pull-right dropdown-toggle" data-toggle="dropdown" href="#">
								<em class="fa fa-cogs"></em>
							</a>
								<ul class="dropdown-menu dropdown-menu-right">
									<li>
										<ul class="dropdown-settings">
											<li><a href="#">
												<em class="fa fa-cog"></em> Settings 1
											</a></li>
											<li class="divider"></li>
											<li><a href="#">
												<em class="fa fa-cog"></em> Settings 2
											</a></li>
											<li class="divider"></li>
											<li><a href="#">
												<em class="fa fa-cog"></em> Settings 3
											</a></li>
										</ul>
									</li>
								</ul>
							</li>
						</ul>
						<span class="pull-right clickable panel-toggle panel-button-tab-left"><em class="fa fa-toggle-up"></em></span></div>
					<div class="panel-body">
					<?php
				$sql="SELECT c.caj_id,c.caj_desc,sum(round((v.ven_precio*0.12)+v.ven_precio,2))as totales
				from venta v
				inner join tbl_caja c on v.caj_id=c.caj_id
				where v.pro_estado='Pagado'
				group by c.caj_id";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<ul>
							<li class="left clearfix"><span class="chat-img pull-left">
							
								</span>
								<div class="chat-body clearfix">
									<div class="header"><strong class="primary-font"><?php echo $producto[1] ?></strong> <small class="text-muted"></small></div>
									<b></b><p>Totales</p>
									<p>$<?php echo $producto[2] ?></p>
								</div>
							</li>
							
						</ul>
						<?php endwhile; ?>
					</div>
					
				</div>
		</div>
		<?php 
       endif;
          ?>
		</div>
</body>
</html>
<?php 
	}else{
		header("location:../index.php");
	}
 ?>