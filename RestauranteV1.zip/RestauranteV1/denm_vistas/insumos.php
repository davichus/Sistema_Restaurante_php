<?php 
session_start();
if(isset($_SESSION['usuario'])){

	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Restaurante/Bar</title>
        <?php require_once "menu.php"; ?>
        <?php require_once "../denm_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
        ?>
        
        <script>
//Función que realiza la suma
     function Suma() {
   var ingreso1 = document.frmPersona.txt_cantidad.value;
   var ingreso2 = document.frmPersona.txt_stock.value;
   try{
      //Calculamos el número escrito:
       ingreso1 = (isNaN(parseFloat(ingreso1)))? 0 : parseFloat(ingreso1);
       ingreso2 = (isNaN(parseFloat(ingreso2)))? 0 : parseFloat(ingreso2);
       document.frmPersona.txt_medidas.value = ingreso1*ingreso2;
   }
   //Si se produce un error no hacemos nada
   catch(e) {}
   }
   
</script>
<script>
//Función que realiza la suma
     function Suma1() {
   var ingreso1 = document.frmPersonaU.cantidad.value;
   var ingreso2 = document.frmPersonaU.stock.value;
   try{
      //Calculamos el número escrito:
       ingreso1 = (isNaN(parseFloat(ingreso1)))? 0 : parseFloat(ingreso1);
       ingreso2 = (isNaN(parseFloat(ingreso2)))? 0 : parseFloat(ingreso2);
       document.frmPersonaU.medidas.value = ingreso1*ingreso2;
   }
   //Si se produce un error no hacemos nada
   catch(e) {}
   }
   
</script>


	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Registro Insumos</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmPersona" name="frmPersona">
                    <label>Insumo</label>
						<input type="text" class="form-control input-sm" name="txt_caja" id="txt_caja">
                    
                    <label>Tipo de Unidad</label>
							<br>
							<select name="sl_tipo" class="form-control input-sm" id="sl_tipo" required>
                          <option value="" disabled selected hidden>--Seleccione--</option>
                          <option value="Botella de Vidrio">Botella de Vidrio</option>
                          <option value="Lata">Lata</option>
                          <option value="Kilo">Kilo</option>
                          <option value="Bolsa">Bolsa</option>
                          <option value="Caja">Caja</option>
                          <option value="Unidad">Unidad</option>
                       
                          </select>
                          <label>Categoria Insumo</label>
                          <select class="form-control input-sm" id="sl_insumo" name="sl_insumo">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT catin_id,
			     catin_desc
				from tbl_categoria_insumo";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
			</select>
                   <label>Medida</label>
							<br>
							<select name="sl_medida" class="form-control input-sm" id="sl_medida" required>
                          <option value="" disabled selected hidden>--Seleccione--</option>
                          <option value="l">Litros</option>
                          <option value="ml">Mililitros</option>
                          <option value="cc">Centimetros Cubicos</option>
                          <option value="g">Gramos</option>
                          <option value="lb">Libras</option>
                          <option value="k">Kilos</option>
                         
                       
                          </select>
                       <label>Cantidad x Medida</label>
						<input type="text" class="form-control input-sm" id="txt_cantidad" name="txt_cantidad"  onKeyUp="Suma()">
                        <label>Stock</label>
						<input type="number" class="form-control input-sm" id="txt_stock" name="txt_stock"  onKeyUp="Suma()" style="width : 60px; heigth : 1px" onclick="Suma()">
                        <br><input type="text" class="form-control input-sm" id="txt_medidas" name="txt_medidas"  style="width : 60px; heigth : 1px" readonly>

                        <label>Precio</label>
						<input type="text" class="form-control input-sm" id="txt_precio" name="txt_precio">
						
                        
						<p></p>
						<span class="btn btn-primary" id="btnAgregarPersona">Agregar</span>
					</form>
				</div>
				<div class="col-sm-8">
					<div id="tablaPersonaLoad"></div>
				</div>
			</div>
		</div>

		<!-- Button trigger modal -->


		<!-- Modal -->
		<div class="modal fade" id="abremodalPersonaUpdate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualizar Insumos</h4>
					</div>
					<div class="modal-body">
						<form id="frmPersonaU" name="frmPersonaU">
                        <input type="text" hidden="" id="id" name="id">
                        <label>Insumo</label>
						<input type="text" class="form-control input-sm" name="caja" id="caja">
                    
                    <label>Tipo de Unidad</label>
							<br>
							<select name="tipo" class="form-control input-sm" id="tipo" required>
                          <option value="" disabled selected hidden>--Seleccione--</option>
                          <option value="Botella de Vidrio">Botella de Vidrio</option>
                          <option value="Lata">Lata</option>
                          <option value="Kilo">Kilo</option>
                          <option value="Bolsa">Bolsa</option>
                          <option value="Caja">Caja</option>
                          <option value="Unidad">Unidad</option>
                       
                          </select>
                          <label>Categoria Insumo</label>
                          <select class="form-control input-sm" id="insumo" name="insumo">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT catin_id,
			     catin_desc
				from tbl_categoria_insumo";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
			</select>
                   <label>Medida</label>
							<br>
							<select name="medida" class="form-control input-sm" id="medida" required>
                          <option value="" disabled selected hidden>--Seleccione--</option>
                          <option value="l">Litros</option>
                          <option value="ml">Mililitros</option>
                          <option value="cc">Centimetros Cubicos</option>
                          <option value="g">Gramos</option>
                          <option value="lb">Libras</option>
                          <option value="k">Kilos</option>
                         
                       
                          </select>
                       <label>Cantidad x Medida</label>
						<input type="text" class="form-control input-sm" id="cantidad" name="cantidad"  onKeyUp="Suma1()">
                        <label>Stock</label>
						<input type="number" class="form-control input-sm" id="stock" name="stock"  onKeyUp="Suma1()" style="width : 60px; heigth : 1px" onclick="Suma1()">
                          
                        <br><input type="text" class="form-control input-sm" id="medidas" name="medidas"  style="width : 60px; heigth : 1px" readonly>
                       
                        <label>Precio</label>
						<input type="text" class="form-control input-sm" id="precio" name="precio">
                      
							
						</form>
					</div>
					<div class="modal-footer">
						<button id="btnAgregarPersonaU" type="button" class="btn btn-primary" data-dismiss="modal">Actualizar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
    </html>
  

    <script type="text/javascript">
		$(document).ready(function(){

			$('#tablaPersonaLoad').load("insumos/tablaInsumo.php");

			$('#btnAgregarPersona').click(function(){

				vacios=validarFormVacio('frmPersona');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmPersona').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/insumos/agregaInsumo.php",
					success:function(r){
						if(r==2){
                            $('#tablaPersonaLoad').load("insumos/tablaInsumo.php");
								alertify.alert("Este Insumo ya ha sido registrado, prueba con otro!!");
							}
						
						else if(r==1){
					//esta linea nos permite limpiar el formulario al insetar un registro
					$('#frmPersona')[0].reset();

                    $('#tablaPersonaLoad').load("insumos/tablaInsumo.php");
					alertify.success("Insumo agregado con exito!!");
				}else{
					alertify.error("No se pudo agregar");
				}
			}
		});
			});
		});
	</script>

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnAgregarPersonaU').click(function(){

				datos=$('#frmPersonaU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/insumos/actualizaInsumo.php",
					success:function(r){
						if(r==1){
                            $('#tablaPersonaLoad').load("insumos/tablaInsumo.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
			function agregaDato(id){

                $.ajax({
                            type:"POST",
                            data:"id=" + id,
                            url:"../denm_procesos/insumos/obtenDatosInsumo.php",
                        success:function(r){
                        dato=jQuery.parseJSON(r);

                        $('#id').val(dato['ins_id']);
                        $('#caja').val(dato['ins_desc']);
                        $('#tipo').val(dato['ins_unidad_tipo']);
                        $('#insumo').val(dato['catin_id']);
                        $('#medida').val(dato['ins_medidad']);
                        $('#cantidad').val(dato['ins_cantidad_medidad']);
                        $('#stock').val(dato['ins_stock']);
                        $('#medidas').val(dato['ins_stock_medida']);
                        $('#precio').val(dato['ins_precio']);
 
}
});
}

		function eliminarProv(idper){
			alertify.confirm('¿Desea eliminar este Insumo?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + idper,
					url:"../denm_procesos/insumos/eliminaInsumo.php",
					success:function(r){
						if(r==1){
                            $('#tablaPersonaLoad').load("insumos/tablaInsumo.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
	
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
<?php 
}else{
	header("location:../index.php");
}
?>