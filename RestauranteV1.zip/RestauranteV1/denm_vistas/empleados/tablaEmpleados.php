<?php 
	require_once "../../denm_clases/conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();
	$sql="SELECT e.emp_id,
    p.per_ced,
    p.per_apepat,
    p.per_apemat,
    p.per_nom,
    c.car_desc,
    s.suc_nombre,
    e.emp_estado
FROM tbl_empleado e 
inner join tbl_persona p on e.per_id=p.per_id
inner join tbl_cargo c on e.car_id=c.car_id
inner join tbl_sucursal s on e.suc_id=s.suc_id
 where e.emp_estado='A'";
	$result=mysqli_query($conexion,$sql);

 ?>

<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><label>Empleados</label></caption>
	<tr>
		<td>Persona</td>
		<td>Cargo</td>
		<td>Sucursal</td>
       
        <td>Estado</td>
		<td colspan="2">Acciones</td>
		
	</tr>

	<?php while($ver=mysqli_fetch_row($result)): ?>

	<tr>
		<td><?php echo $ver[1]; ?> <?php echo $ver[2]; ?> <?php echo $ver[3]; ?> <?php echo $ver[4]; ?></td>
		<td><?php echo $ver[5]; ?></td>
		<td><?php echo $ver[6]; ?></td>
		<td><?php echo $ver[7]; ?></td>
		
		<td>
			<span  data-toggle="modal" data-target="#actualizaCaja" class="btn btn-warning btn-xs" onclick="agregaDato('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
		<td>
			<span class="btn btn-danger btn-xs" onclick="eliminaEsp('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-remove"></span>
			</span>
		</td>
	</tr>
<?php endwhile; ?>
</table>