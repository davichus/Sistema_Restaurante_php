function selectpaises() {
	var id_pais = $("#sl_centro").val();
	$.ajax({
		url: "select.ajax.php",
		method: "POST",
		data: {
			"id":id_pais
		},
		success: function(respuesta){
			$("#sl_medico").attr("disabled", false);
			$("#sl_medico").html(respuesta);
		}
	})
}